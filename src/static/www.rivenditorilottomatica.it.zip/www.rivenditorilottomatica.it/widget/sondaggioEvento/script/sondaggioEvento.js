$(function(){
	$("a[data-idsondaggio]").each(function(index, link){
		Handlebars.registerHelper("setIndex", function(value){
			this._index = Number(value);
		});
		
		Handlebars.registerHelper("setCounter", function(value){
			this._counter = Number(value) + 1;
		});
		
		var href 	= $(link).attr("href") 		? $(link).attr("href") 	: "";
		var onclick = $(link).attr("onclick") 	? $(link).attr("onclick") 	: "";
		var jclick	= $(link).click;
		
		$(link)
		//.unbind("click")
		.removeAttr("onclick")
		.attr("href", "javascript: void(0)");
		
		$("body").off("click", link, jclick);
		
		$(link).click(function(event){
			event.preventDefault();
			
			var $this = $(this);
			
			$.ajax({
				type	: "POST",
				url		: "/portaleb2b/partecipa/rest/getSondaggioEvento.do",
				async	: false,
				data	: {
					idSondaggio : $(this).attr("data-idSondaggio")
				},
				success	: function(data) {
					if($this.data('template')){
						return showSondaggioEventoTemplate(data, this, href, onclick, jclick, $this.data('template'));
					}
					else{
						return showSondaggioEvento(data, this, href, onclick, jclick);
					}
				}
			});
		});
	});
	
	function showSondaggioEventoTemplate(evento, link, href, onclick, jclick, template, popup){
		if(evento && evento.show){
			$.get("/widget/sondaggioEvento/templates/sondaggioEvento-" + template + ".template", function(data){
				var template 	= Handlebars.compile(data);
				var html    	= template({
					domanda		: evento.sondaggio.domanda,
					idSondaggio : evento.sondaggio.id,
					risposte	: evento.sondaggio.risposte
				});
				
				if(!popup){
					popup = $(html).showPopup({
						onClose: function(){
							eval(onclick);
							$("body").on("click", link, jclick);
							$(link).click();
							window.location = href;
						}
					});
				}
				
				popup.find("form#contentPopupForm").html(html);
				popup.center();

				popup.find(".btn-annulla").click(function(){
					popup.data("overlay").close();
				});
				
				popup.find(".btn-invia").click(function(){
					$("#error").hide();
					
					var executeAjax = true;
					popup.find(".question").each(function(index, tr){
						if($(tr).find("input:checked").size() == 0){
							executeAjax = false;
						}
					});
					
					if(executeAjax){
						$.ajax({
							type	: "POST",
							url		: "/portaleb2b/partecipa/rest/votoSondaggioEvento.do",
							data	: popup.find("form#contentPopupForm").serialize(),
							success	: function(data) {
								popup.data("overlay").close();
							}
						});
					}
					else{
						$("#error").show();
					}
				});
			});
		}
		else{
			eval(onclick);
			$("body").on("click", link, jclick);
			$(link).click();
			window.location = href;
		}
	}
	
	function showSondaggioEvento(evento, link, href, onclick, jclick){
		if(evento && evento.show){
			$.get("/widget/sondaggioEvento/templates/sondaggioEvento-step1.template", function(data){
				var template 	= Handlebars.compile(data);
				var html    	= template({
					nome		: evento.nomeUtente, 
					cognome		: evento.cognomeUtente,
					descrizione	: evento.sondaggio.descrizione
				});
				
				var popup 		= $(html).showPopup({
					onClose: function(){
						eval(onclick);
						$("body").on("click", link, jclick);
						$(link).click();
						window.location = href;
					}
				});
				
				popup.find("#btn-unanswer").click(function(){
					$.ajax({
						type	: "POST",
						url		: "/portaleb2b/partecipa/rest/setSondaggioEvento.do",
						data	: {
							idSondaggio	: evento.sondaggio.id,
							answerStatus: 2
						},
						success	: function(data) {
							popup.data("overlay").close();
						}
					});
				});
				
				popup.find("#btn-reset").click(function(){
					$.ajax({
						type	: "POST",
						url		: "/portaleb2b/partecipa/rest/setSondaggioEvento.do",
						data	: {
							idSondaggio	: evento.sondaggio.id,
							answerStatus: 3
						},
						success	: function(data) {
							popup.data("overlay").close();
						}
					});
				});
				
				popup.find("#btn-step2").click(function(){
					showSondaggioEventoTemplate(evento, link, href, onclick, jclick, 'step2', popup);
					
//					$.get("/widget/sondaggioEvento/templates/sondaggioEvento-step2.template", function(data){
//						var template 	= Handlebars.compile(data);
//						var html    	= template({
//							domanda		: evento.sondaggio.domanda,
//							idSondaggio : evento.sondaggio.id,
//							risposte	: evento.sondaggio.risposte
//						});
//						
//						popup.find("form#contentPopupForm").html(html);
//						popup.center();
//
//						popup.find(".btn-annulla").click(function(){
//							popup.data("overlay").close();
//						});
//						
//						popup.find(".btn-invia").click(function(){
//							$("#error").hide();
//							
//							var executeAjax = true;
//							popup.find(".question").each(function(index, tr){
//								if($(tr).find("input:checked").size() == 0){
//									executeAjax = false;
//								}
//							});
//							
//							if(executeAjax){
//								$.ajax({
//									type	: "POST",
//									url		: "/portaleb2b/partecipa/rest/votoSondaggioEvento.do",
//									data	: popup.find("form#contentPopupForm").serialize(),
//									success	: function(data) {
//										popup.data("overlay").close();
//									}
//								});
//							}
//							else{
//								$("#error").show();
//							}
//						});
//					});
				});
			});
		}
		else{
			eval(onclick);
			$("body").on("click", link, jclick);
			$(link).click();
			window.location = href;
		}
	}
});