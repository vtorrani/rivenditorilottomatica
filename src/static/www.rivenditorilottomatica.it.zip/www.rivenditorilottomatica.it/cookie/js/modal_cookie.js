/*START MODAL COOKIE*/

function check_accept_cookie(){
	if(window.console)console.log("***** check_accept_cookie ***** ");
	var cookieAccept = getUserCookie('PORTB2B_ACCEPT_COOKIE');
	 if (cookieAccept) {
		if(window.console)console.log("***** cookie found ***** ");
	} else {
		if(window.console)console.log("***** cookie does not found ***** ");
		createModalCookie();
		showModalCookie();
	}
}


function createModalCookie() {
	modalDiv = $('#modal_cookie').detach();
	modalDiv.appendTo('body');
	var modalDiv = $('#modal_cookie-mask').detach();
	modalDiv.appendTo('body');
	}

function showModalCookie() {
	$('#modal_cookie').load( "/cookie/info_cookie.html", function() {
		var boxWidth = '550';
		var boxHeight = 'auto';
		$('#modal_cookie').css({'width':boxWidth,'height':boxHeight});
		var maskHeight = $(document).height();
		var maskWidth = $(window).width();
		$('#modal_cookie-mask').css({'width':maskWidth,'height':maskHeight});  
		$('#modal_cookie-mask').fadeTo("slow",0.75);
		$('#menurow').css('z-index','0');
		$('#footer').css('z-index','0');
		var winH = $(window).height();
		var winW = $(window).width();
		$('#modal_cookie').css('top',  winH/2-$('#modal_cookie').height()/2);
		$('#modal_cookie').css('left', winW/2-$('#modal_cookie').width()/2);
		$("#modal_cookie .text_container").mCustomScrollbar({
			scrollButtons:{
				enable:false
			}
		});	
		$('#modal_cookie').fadeIn(1800);
		$(window).resize(function () {
			var divmodal = $('#modal_cookie');
			var maskHeight = $(document).height();
			var maskWidth = $(window).width();
			$('#modal_cookie-mask').css({'width':maskWidth,'height':maskHeight});
			var winH = $(window).height();
			var winW = $(window).width();
			divmodal.css('top',  winH/2 - divmodal.height()/2);
			divmodal.css('left', winW/2 - divmodal.width()/2);
		});
		action_SC_OpWin_Cookie();
	});
}

function hideModalCookie() {
	$('#modal_cookie').hide();
	$('#modal_cookie-mask').hide();
}

function set_accept_cookie(){
	
	var cookie_date = new Date();
	cookie_date.setTime(cookie_date.getTime() + (60 * 1000 * 60 * 24 * 365 * 2));	
	var cookieName = 'PORTB2B_ACCEPT_COOKIE';
	var cookieValue = 'true';
	var myDate = new Date();
	document.cookie = cookieName +"=" + cookieValue + ";expires=" + cookie_date.toUTCString() + ";domain=.rivenditorilottomatica.it;path=/";
	hideModalCookie();
	action_SC_Accept_Cookie();
}

function getUserCookie(w){
	cName = "";
	pCOOKIES = new Array();
	pCOOKIES = document.cookie.split('; ');
	for(bb = 0; bb < pCOOKIES.length; bb++){
		NmeVal  = new Array();
		NmeVal  = pCOOKIES[bb].split('=');
		if(NmeVal[0] == w){
			cName = unescape(NmeVal[1]);
		}
	}
	return cName;
}



