$(function(){
	/*
	 * Rilevazione Invio del Suggerimento
	 */  
	
	// Area Privata
	extendOnclick($("#homePrivSubmitFeedback")	, "action_SC_Suggested");
	
	if($("#haveSuggestionButton").size() > 0){
		// E' necessario fare cosi'perche' la form di invio di un suggerimento e' lo stesso dell'invio di un sondaggio
		extendOnclick($("#formSuggButton")			, "action_SC_Sends_Participates");
		// Sezione Partecipa
		extendOnclick($("#haveSuggestionButton")	, "action_SC_Participates");
	}
	
	/*
	 * Rilevazione Commenti ai Suggerimenti
	 */
	//call action SC
	extendOnclick($("input[type=button][id^=replyFeedback_]"), "action_SC_Comments", ["$('#categoriesTabs li.tabOn').attr('data-category')"]);
	
	/*
	 * Rilevazione Invio Richiesta di Assistenza
	 */
	extendOnclick($("#inviaRichiesta")			, "action_SC_Assistance_Request", ["$('#areaAssistenzaSelect option:selected').text()", "$('#sottoAreeSelect option:selected').text()", "$('#riferimentoContattoSelect option:selected').text()"]);
	extendOnclick($("#assTelLink")				, "action_SC_Phone_Assistance");
	
	/*
	 * Rilevazione Risposta ed Invio Sondaggio
	 */
	// Area Privata
	extendOnclick($("#homePageVoteButton")		, "action_SC_Sends_Survey");

	// Sezione Partecipa - Risposte
	extendOnclick($("input[type=submit][id^=replySondaggio_]")	, "action_SC_Participates_Response");
	
	if($("#havePollSuggestionButton").size() > 0){
		// E' necessario fare cos� perche' la form di invio di un sondaggio � lo stesso dell'invio di un suggerimento
		extendOnclick($("#formSuggButton")				, "action_SC_Sends_Proposed");
		extendOnclick($("#havePollSuggestionButton")	, "action_SC_Proposed_Survey");
	}
	
	// Ancore
	extendOnclick($("a[href*='#']"), "proxy_action_SC_Link_A");
	
	// Accordion
	extendOnclick($(".icon.toggle, .showHiddenAccItem").not('.faq-lotto'), "proxy_action_SC_Link_A_Ancor");
	
	// Stampa PDF (in realt� sono div html)
	extendOnclick($(".tsw-print").not("[data-fileName]"), "action_SC_Print_Att", ["window.location.pathname.substring(window.location.pathname.lastIndexOf('/') + 1)"]);
	
	// Stampa PDF (in realt� sono div html)
	extendOnclick($(".tsw-print[data-fileName]"), "action_SC_Print_Att", ["$(this).attr('data-fileName')"]);

	// Download PDF
	extendOnclick($(".tsw-download"), "action_SC_Download_Att", ["$(this).attr('data-fileName')"]);

	// Diventa rivenditore HP pubblica
	extendOnclick($("#diventaRivHPPubl"), "action_SC_Extends", ["'navigate'", "'Diventa Rivenditore'", "'Step Dati Anagrafici'"]);

	// Monitoraggio Transazioni
	//extendOnclick($("#btnSearchMonitoringTransaction"), "action_SC_Click_VerificaTransazioni", ["$('#selectMacroServizio option:selected').text()", "$('#selectTipoTransazione option:selected').text()", "$('#inputCodiceUtente').val()", "$('#selectGestore option:selected').text()"]);

	// Monitoraggio Vincite
	//extendOnclick($("#btnSearchMonitoringWinning"), "action_SC_Monitoring_Winnings", ["$('#selectGioco option:selected').text()", "$('#dataInizio').val() + '_' + $('#dataFine').val()", "$('#inputCodiceUtente').val()"]);
	
	// Paga Ora Mybank
	$('.section.deffered#tabAddebitiInsoluti').data('callback', proxy_action_SC_Click_PayNow);
		
	// Mybank result
	proxy_action_SC_MyBankResult();
	
	// Call Deflaction
	proxy_action_SC_SpedizioniGEV();
	proxy_action_SC_SpedizioniMDC()
	proxy_action_SC_Addebiti();
	//btnSearchMonitoringWinningextendOnclick(jQuery("#btnSearchMonitoringWinning"), "action_SC_Click_VerificaVincite");
//	extendOnclick(jQuery("#btnSearchMonitoringTransaction"), "action_SC_Click_VerificaTransazioni", ["jQuery('#selectMacroServizio option:selected').text()", "jQuery('#selectTipoServizio option:selected').text()", "jQuery('#selectServizio option:selected').text()", "jQuery('#inputCodiceUtente).val()"]);
	// manca click su accordion addebiti
		
	// Catalogo gev
	$('#btn-ordine-ultimo').data('callback', function(ordine){
		action_SC_Click_Ultimo_Ordine(ordine);
	});
	
	$('#btn-ordine-preferito').data('callback', function(ordine){
		action_SC_Click_Ordine_Preferito(ordine);
	});
	
	extendOnclick($('#carrello-preferito'), 'proxy_action_SC_Click_Salva_Ordine_Preferito');
	
	$('#lastOrders .btn.btn-yellow').live("click", function(){
		proxy_action_SC_Click_Aggiungi_Ultimo_Ordine($('#lastOrders').data('prodotti'), $(".tabsUltimiOrdini li.active a").html());
	});
	
	$('#preferredOrders .btn.btn-yellow').live("click", function(){
		proxy_action_SC_Click_Aggiungi_Ordine_Preferito($('#preferredOrders').data('prodotti'));
	});
	//END Catalogo gev
	
	
	//Magazzino - 04/05/2016
	//Click sul pulsante "Vai agli ordini GeV"
	extendOnclick($("#retailSuppliesRetailPrintArea #carrello"), "proxy_action_SC_Click_VaiOrdiniGev");
	
	//Click sul pulsante "Download schermata stock"
	extendOnclick($("#retailSuppliesRetailPrintArea .icon.xls-d"), "proxy_action_SC_Click_DownloadStock");
	
	//Click sul pulsante "Stampa schermata stock"
	extendOnclick($("#retailSuppliesRetailPrintArea .icon.print.tsw-print"), "proxy_action_SC_Click_StampaStock");
	
	//Click sul pulsante "Annulla selezioni nello stock"
	extendOnclick($("#retailSuppliesRetailPrintArea #annulla"), "proxy_action_SC_Click_AnnullaSelezioniStock");
	//End Magazzino - 04/05/2016
	
	//Lotto: Sezione informativa
	//Visualizzazione contenuto Starter KIT (Click su "Vedi Contenuto KIT")
	extendOnclick($('#subTemplate_lotto .lottoInfoVediContenuto'), "action_SC_Click_Lotto_Contenuto_Starter_Kit");

	//Tracking pacco
	extendOnclick($("#subTemplate_lotto #lottoInfoTrackingPacco"), "action_SC_Click_Lotto_Tracking_Pacco");
	
	//Visualizzazione delle foto della dotazione tecnica
	extendOnclick($("#subTemplate_lotto .lottoInfoGalleriaFoto"), "proxy_action_SC_Click_Lotto_Visualizzazione_Foto_Dotazione_Tecnica");
		
	//Accesso al Questionario post vista del tecnico
	extendOnclick($("#subTemplate_lotto #monitoraggio"), "action_SC_Click_Lotto_Questionario_Post_Vista_Tecnico");
	//END - Lotto: Sezione informativa
	
//	//Lotto: Sezione dedicata alla formazione
//	//Accesso al questionario (se non incluso nel tutorial della formazione)
//	extendOnclick($("#subTemplate_lotto #elearning_btn"), "action_SC_Click_Lotto_Questionario");
//		
//	//Download manuale (intero e singoli capitoli)
//	extendOnclick($("#daDefinire"), "action_SC_Click_Lotto_Download_Manuale", ["jQuery(this).data('area')", "jQuery(this).data('nome_capitolo')"]);
//	//END - Lotto: Sezione dedicata alla formazione
	
	//Lotto: Sezione dedicata alle FAQ
	//Clic per visualizzazione di ogni singola FAQ
//	extendOnclick($("#subTemplate_lotto .faq-accordion-open"), "proxy_action_SC_Click_Lotto_FAQ");
	extendOnclick($("#subTemplate_lotto .icon.toggle.faq-lotto"), "proxy_action_SC_Click_Lotto_FAQ");
	//END - Lotto: Sezione dedicata alle FAQ
	
	// MDC - 27/12/2016
	if(location.href.indexOf('/catalogo/ordini/mdc') > 0){
		extendOnclick($('#carrello-procedi-ordine'), 'proxy_action_SC_Procedi_Ordine_MDC');
		
		// START - Popup Click su Invio anticipato dell'ordine
		$('body').on('click', '#contentPopup #anticipate', function(){
			action_SC_Invio_Anticipato_Ordine_MDC(this);
		});
		// END - Popup Click su Invio anticipato dell'ordine
		
		// Inserire il nome del bottone: "Chiudi" (X) , "Torna al catalogo", "Procedi all'ordine", "Conferma l'ordine"
		$('body').on('click', '#dialog-box #closePopup, #contentPopup #proceed, #contentPopup #back, .btn-torna-catalogo, #btnMdcOrderConfirm', function(){
			proxy_action_SC_Interazioni_Ordini_MDC(this);
		});
		// END - Popup Click su Invio anticipato dell'ordine
	}
	// END MDC - 27/12/2016
		
	//PERFORMANCE GEV
	extendOnclick($("#btn_showGraph"), "action_SC_Click_RicercaTrend", ["$('#trendBusiness :selected').text()", "$('#tipoIndicatore :selected').text()"]);
	extendOnclick($("#area"), "action_SC_Click_TipoGrafico", ["$('#area').attr('id')"]);
	extendOnclick($("#bar"), "action_SC_Click_TipoGrafico", ["$('#bar').attr('id')"]);
	extendOnclick($(".suggestElem"), "action_SC_Click_Suggest", ["$(this).text()"]);

});

// funzioni non applicabili con $
function proxy_action_SC_Calendar_Selection(typeCs, actionCs){
	/*
	 * Viene richiamato da:
	 * - /widget/script/candario.js
	 */
	action_SC_Calendar_Selection(typeCs, actionCs, this);
}

function proxy_action_SC_Link_A_Ancor(link){
	action_SC_Link_A("accordion", link);
}

function proxy_action_SC_Link_A(link){
	var href = $(link).attr("href");
	var title = href.substring(href.indexOf("#") + 1);
	
	if($.trim(title) != ""){
		action_SC_Link_A(title, link);
	}
}

function proxy_action_SC_Click_PayNow(){
	extendOnclick(jQuery(".btnPayNow"), "action_SC_Click_PayNow");
}

function proxy_action_SC_MyBankResult(){
	var myBankResult = $('#myBankResult');
	if (myBankResult.size() > 0){
		var idTransaction = $(myBankResult).data('idtransaction');
		var idBp = $(myBankResult).data('idbp');
		var idPos = $(myBankResult).data('idpos');
		var esitoReturn = $(myBankResult).data('esitoreturn');
		
		action_SC_MyBankResult(idTransaction,idBp,idPos,esitoReturn);
	}
}

function proxy_action_SC_SpedizioniGEV(){
	var pageSpedizioniGEV = $('#pageSpedizioniGEV');
	if (pageSpedizioniGEV.size() > 0){
		action_SC_Click_SpedizioniGEV()
	}
}

function proxy_action_SC_SpedizioniMDC(){
	var pageSpedizioniMDC = $('#pageSpedizioniMDC');
	if (pageSpedizioniMDC.size() > 0){
		action_SC_Click_SpedizioniMDC();
	}
}

function proxy_action_SC_Addebiti(){
	$('#tabsMonitoraggioContabile .tabs ul li a:eq(0)').click(function(){ action_SC_Click_TabAddebiti() });
	$('#tabsMonitoraggioContabile .tabCont:eq(0):visible').each(function(){ action_SC_Click_TabAddebiti() });
}

function proxy_action_SC_Click_Aggiungi_Ultimo_Ordine(ordine,tab){
	action_SC_Click_Aggiungi_Ultimo_Ordine(ordine,tab);
}

function proxy_action_SC_Click_Aggiungi_Ordine_Preferito(ordine){
	action_SC_Click_Aggiungi_Ordine_Preferito(ordine);
}

function proxy_action_SC_Click_Salva_Ordine_Preferito(){
	var prodotti = [];
	
	$('#carrelloForm [name=prodotti]').each(function(){
		prodotti.push($(this).val());
	});

	action_SC_Click_Salva_Ordine_Preferito(prodotti.join(','));
}

//Click sul pulsante "Vai agli ordini GeV"
function proxy_action_SC_Click_VaiOrdiniGev(FunctionSC){
	var prodotti = []; 
	
	$('#toCatalouge input[type="hidden"][name="prodotti"]').each(function(){
		prodotti.push($(this).val());
	});
	
	action_SC_Click_VaiOrdiniGev(prodotti.join(','), FunctionSC);
}

//Click sul pulsante "Download schermata stock"
function proxy_action_SC_Click_DownloadStock(FunctionSC){
	var prodotti = []; 
	
	$('#toCatalouge input[type="hidden"][name="prodotti"]').each(function(){
		prodotti.push($(this).val());
	});
	
	action_SC_Click_DownloadStock(prodotti.join(','), FunctionSC);
}

//Click sul pulsante "Stampa schermata stock"
function proxy_action_SC_Click_StampaStock(FunctionSC){
	var prodotti = []; 
	
	$('#toCatalouge input[type="hidden"][name="prodotti"]').each(function(){
		prodotti.push($(this).val());
	});
	
	action_SC_Click_StampaStock(prodotti.join(','), FunctionSC);
}

//Click sul pulsante "Annulla selezioni nello stock"
function proxy_action_SC_Click_AnnullaSelezioniStock(){
	var prodotti = []; 
	
	$('#toCatalouge input[type="hidden"][name="prodotti"]').each(function(){
		prodotti.push($(this).val());
	});
	
	action_SC_Click_AnnullaSelezioniStock(prodotti.join(','));
}
	
//Lotto: Sezione informativa
//Visualizzazione delle foto della dotazione tecnica
function proxy_action_SC_Click_Lotto_Visualizzazione_Foto_Dotazione_Tecnica(dotazione){
	// .text() per ripulire il testo (contiene condice html)
	var title = $(dotazione).data('title');
	action_SC_Click_Lotto_Visualizzazione_Foto_Dotazione_Tecnica(title);
}
//END - Lotto: Sezione informativa

//Lotto: Sezione dedicata alle FAQ
//Clic per visualizzazione di ogni singola FAQ
function proxy_action_SC_Click_Lotto_FAQ(faqAccordion){
	//il controllo serve perch� anche se cambia classe, rimane agganciato il trigger
//	if($(faqAccordion).hasClass('faq-accordion-open')){
//		var area = $(faqAccordion).closest('.faq_area').find('.faq-titolo h1').text();
//		var faq = $(faqAccordion).text();
//		action_SC_Click_Lotto_FAQ(area, faq);
//	}
	if($(faqAccordion).hasClass('open')){
		var area = $(faqAccordion).closest('.faq_area').find('.faq-titolo h2').text();
		var faq = $(faqAccordion).closest('.item-assitenza').children('h4').text();
		action_SC_Click_Lotto_FAQ(area, faq);
	}
}
//END - Lotto: Sezione dedicata alle FAQ

// MDC - 27/12/2016
function proxy_action_SC_Procedi_Ordine_MDC(){
	var popupShowed = $('#contentPopup #confirm-dispatch-type').is(':visible');
	
	action_SC_Procedi_Ordine_MDC(popupShowed);
}

// Inserire il nome del bottone: "Chiudi" (X) , "Torna al catalogo", "Procedi all'ordine", "Conferma l'ordine"
function proxy_action_SC_Interazioni_Ordini_MDC(button){
	var buttonId 	= $(button).attr('id');
	var buttonClass = $(button).attr('class');
	var buttonName 	= '';
	
	if(buttonId == 'proceed'){
		buttonName = 'Procedi all\'ordine';
	}
	else if(buttonId == 'closePopup'){
		buttonName = 'Chiudi (X)';
	}
	else if(buttonId == 'back' || $(button).hasClass('btn-torna-catalogo')){
		buttonName = 'Torna al catalogo';
	}
	else if(buttonId == 'btnMdcOrderConfirm'){
		buttonName = 'Conferma l\'ordine';
	}
	
	action_SC_Interazioni_Ordini_MDC(buttonName);
}
// END - Popup Click su Invio anticipato dell'ordine
// END MDC - 27/12/2016

// end funzioni non applicabili con $

function extendOnclick(obj, methodString, params){
	$.each(obj, function(index, item){
		var jItem 			= $(item);
		var onclick 		= jItem.attr("onclick");
		var _params 		= params;
		var _methodString 	= methodString;

		if(_params == undefined){
			_params = [];
		}
		
		if(onclick && onclick != ""){
			onclick = "function(){ " + onclick + " }";
			_params.push(onclick);
		}
		
		_params.push("this");
		
		_methodString += "(";
		_methodString += _params.join(", ");
		_methodString += "); return false;";
		
		jItem.attr("onclick", _methodString);
	});
}

function proxy_action_SC_Stampa_Statistiche_Lotto_DEL(sezione){
	action_SC_Stampa_Statistiche_Lotto_DEL(sezione);
}
