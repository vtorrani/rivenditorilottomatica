$(document).click(function(e) {
	$('.select-skinned > ul').hide();
	$('.select-skinned').css('z-index','');
});

(function($) {
	$.fn.skinner = function(opt){
		var cfg = {'type':'block','width':'auto','textwrap':false,'maxitem':'6','reload':true};    
	    if(opt){$.extend(cfg,opt);}
		var element = this;
		var skin = {
			selectskinned: function (element){
				$(element).each(function(){
					sc = $(this);
					sc.wrap('<div class="select-skinned" />');
					childrennn = $('<ul></ul>').hide();
					sc.children('option').each(function(i,e){				
						myText = ($(e).html()=='') ? '&nbsp;' : $(e).html();
//						isSelected = ($(e).attr('selected')=='selected') ? ' class="selected"' : ' class=""';
//						itemLI = $('<li'+isSelected+'>'+myText+'</li>').click(function(){
						
						// START MODIFICA
						// Aggiunti i class e i style applicati agl'options
						cssStyle = $(e).attr('style') ? $(e).attr('style') : '';
						cssClass = $(e).attr('class') ? $(e).attr('class') : '';
						cssClass += ($(e).attr('selected') == 'selected') ? ' selected' : '';
						
						itemLI = $('<li class="' + cssClass + '" style="' + cssStyle + '">' + myText+'</li>').click(function(){
							// END MODIFICA
							
							$(this).parents('.select-skinned').css('z-index','');
							itemUL = $(this).parent('ul');
							itemUL.hide();
							itemUL.next('select').find('option').removeAttr('selected');
							itemUL.next('select').find('option').eq(i).attr('selected','selected');
							testoSelected = (itemUL.next('select').find('option').eq(i).text()=='') ? '&nbsp;' : itemUL.next('select').find('option').eq(i).text();
							itemUL.prev('div.select-skinned-text').html('<div class="select-skinned-cont">' + testoSelected + '</div>');
							itemUL.next('select').change();					
						});
						childrennn.append(itemLI);
						childrennn.hover(function(){},function(){
							$(this).hide(); 
							$(this).parents('.select-skinned').css('z-index','');
						});						
						/*$(document).click(function(e) {
							$('.select-skinned > ul').hide();
							$('.select-skinned').css('z-index','');
						});*/
						$('div.select-skinned').click(function(e) { e.stopPropagation(); });					
					});
							
					testoSel = (sc.children('option:selected').text()=='') ? '&nbsp;' : sc.children('option:selected').text();			
					selectedItem = $('<div class="select-skinned-text"><div class="select-skinned-cont">'+testoSel+'</div></div>');
					selectedItem.click(function(){ 
						$('.select-skinned').find('ul').hide(); 
						$('.select-skinned').css('z-index','0')
						$(this).parent('.select-skinned').css('z-index','1100');
						elemUL = $(this).next('ul');						
						pos = $(this).parent('.select-skinned').position();
						bodyScroll = $('body').scrollTop();
						if($(window).height()<=(pos.top+elemUL.outerHeight()+15-bodyScroll)){
							elemUL.css({'top':'auto','bottom':'0'})
						}else{
							elemUL.css({'top':$(this).prev('div.select-skinned-text').children('div.select-skinned-cont').height(),'bottom':'auto'});				
						}
						if($(window).width()<=(pos.left+elemUL.outerWidth())){
							elemUL.css({'left':'auto','right':'0'})
						}else{
							elemUL.css({'left':'0','right':'auto'})
						}
						if(elemUL.is(':visible')){ elemUL.hide(); }else{ elemUL.show(); }
						if(cfg.maxitem){
							hTotItem = 0;
							for(i=0;i<cfg.maxitem;i++){
								hTotItem += elemUL.children('li:eq('+i+')').outerHeight();
							}
							elemUL.css({'overflow-y':'scroll','height':hTotItem+'px'});	
						}					
					});
					sc.before(selectedItem);
					sc.before(childrennn);						
					sc.change(function(){ skin.checkSelect(element); });
					sc.hide();					
				});
				skin.addStyle();
				
			},
			
			checkSelect : function(elem){
				$(elem).each(function(){
					e = $(this);
					e.prev('ul').html('');
					e.children('option').each(function(i,el){
						mytext = ($(el).html()=='') ? '&nbsp;' : $(el).html();
						isSelected = ($(el).attr('selected')=='selected') ? ' class="selected"' : ' class=""';
						itemLI = $('<li'+isSelected+'>'+mytext+'</li>').click(function(){
							itemUL = $(this).parent('ul');
							itemUL.hide();
							itemUL.next('select').find('option').removeAttr('selected');
							itemUL.next('select').find('option').eq(i).attr('selected','selected');
							itemUL.prev('div.select-skinned-text').html('<div class="select-skinned-cont">'+itemUL.next('select').find('option').eq(i).text()+'</div>');
							itemUL.next('select').change();
						});
						e.prev('ul').append(itemLI);						
					});	
				});				
				skin.addStyle();
			},
			
			resetSelect : function(e){
				if($(e).parent('div.select-skinned').size()!=0){
					$(e).prev('ul').remove();
					$(e).prev('div.select-skinned-text').remove();
					$(e).unwrap('div.select-skinned');
					$(e).show();
					skin.selectskinned(e);
				}else{
					skin.selectskinned(e);
				}
			},
			
			addStyle : function(){
				if(cfg.type!='block'){ $(element).parent('div.select-skinned').css({'float':cfg.type}); }	
				
				if (opt!=null && opt.width !=null && opt.width != '')
					$(element).parent('div.select-skinned').width(opt.width);
				else
					$(element).parent('div.select-skinned').width(cfg.width);				
				if(cfg.textwrap){ $(element).parent('div.select-skinned').children('ul').children('li').css({'white-space':'normal'}); }
				$('div.select-skinned > ul > li').hover( function(){$(this).addClass('hover');}, function(){$(this).removeClass('hover');} );
			}
		}		
		if(cfg.reload){
			skin.resetSelect(element);
		}else{
			skin.selectskinned(element);
		}	
		return this;	
	}
})(jQuery);