/* NEW */

var R = window.R || { vars: {}, fun: {} };

var isRegistration = $('#isRegistration').val();

// Regole di convalida
R.fun.rulesValidation = {

 accettazioneTrattamentoDati: {
  req: function( $selector ) {
   return ( $selector.attr( 'checked' ) == 'checked' )? '' : '&Egrave; necessario accettare il consenso ai trattamenti dei dati personali';
  },
  all: function( $selector ) {
   return R.fun.rulesValidation.accettazioneTrattamentoDati.req( $selector );
  }
 },

 codiceFiscale: {
  req: function( $selector ) {
   return $selector.val() ?  '' : 'Inserire il codice fiscale';
  },
  val: function( $selector ) {
   //return $selector.val().match( /^([0-9]{11}|[a-z0-9]{16})$/i ) ? '' : 'Il codice fiscale non risulta corretto';
	  return $selector.val().match( /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{16,}$/i ) ? '' : 'Inserisci correttamente il tuo codice fiscale';	  
  },
  all: function( $selector ) {
   return R.fun.rulesValidation.codiceFiscale.req( $selector ) || R.fun.rulesValidation.codiceFiscale.val( $selector );
  }
 },

 username: {
  req: function( $selector ) {
   return $selector.val() ? '' : 'Inserire lo username';
  },
  val: function( $selector ) {
   return $selector.val().match( /[^a-z0-9@#!\$\.:_]/i ) ? 'Lo username contiene caratteri non consentiti' : '';
  },
  len: function( $selector ) {
   return ( ( $selector.val().length < 6 ) || ( $selector.val().length > 20 ) )? 'Lo username deve avere tra 6 e 20 caratteri' : '';
  },
  val2: function( $selector ) {
   return $selector.val().match( /[a-z0-9]/i ) ? '' : 'Lo username deve avere almeno un valore alfanumerico';
  },
  all: function( $selector ) {
    if(isRegistration=="true"){
      return R.fun.rulesValidation.username.req( $selector ) || R.fun.rulesValidation.username.val( $selector ) || R.fun.rulesValidation.username.len( $selector ) || R.fun.rulesValidation.username.val2( $selector );
    }else{
      return R.fun.rulesValidation.username.req( $selector ) || R.fun.rulesValidation.username.len( $selector ) || R.fun.rulesValidation.username.val2( $selector );
    }
  }
 },

 password: {
  req: function( $selector ) {
   return $selector.val() ? '' : 'Inserire la password';
  },
  val: function( $selector ) {
   return true ? '' : 'La password contiene caratteri non consentiti';
  },
  len: function( $selector ) {
   return ( ( $selector.val().length < 8 ) || ( $selector.val().length > 20 ) )? 'La password deve avere tra 8 e 20 caratteri' : '';
  },
  val2: function( $selector ) {
   return $selector.val().match( /[0-9]/i ) ? '' : 'La password deve contenere almeno un valore numerico';
  },
  val3: function( $selector ) {
   return $selector.val().match( /[A-Z]/ ) ? '' : 'La password deve contenere almeno un carattere maiuscolo';
  },
  val4: function( $selector ) {
   return $selector.val().match( /[a-z]/ ) ? '' : 'La password deve contenere almeno un carattere minuscolo';
  },
  val5: function( $selector ) {
   var username = $( '#username' ).size() ? $( '#username' ).val().toLowerCase() : '';
   var nome = $( '#nome' ).size() ? $( '#nome' ).val().toLowerCase() : '';
   var cognome = $( '#cognome' ).size() ? $( '#cognome' ).val().toLowerCase() : '';
   var dataNascita = $( '#dataNascita' ).size() ? $( '#dataNascita' ).val() : ''; // d/m/Y

   if( dataNascita.match( /^\d{2}\/\d{2}\/\d{4}$/ ) ) {
    var dnarr = dataNascita.split( '/', 3 );
    window.dataNascita2 = dnarr[0] + dnarr[1] + dnarr[2]; // dmY
    window.dataNascita3 = dnarr[0] + '-' + dnarr[1] + '-' + dnarr[2]; // d-m-Y
    window.dataNascita4 = dnarr[0] + '.' + dnarr[1] + '.' + dnarr[2]; // d.m.Y
    window.dataNascita5 = dnarr[2] + dnarr[1] + dnarr[0]; // Ymd
    window.dataNascita6 = dnarr[2] + '-' + dnarr[1] + '-' + dnarr[0]; // Y-m-d
    window.dataNascita7 = dnarr[2] + '.' + dnarr[1] + '.' + dnarr[0]; // Y.m.d
   }

   if( username && $selector.val().toLowerCase().search( username ) > -1 )
    return 'La password non deve contenere l\'username';
   else if( nome && $selector.val().toLowerCase().search( nome ) > -1 )
    return 'La password non deve contenere il nome';
   else if( cognome && $selector.val().toLowerCase().search( cognome ) > -1 )
    return 'La password non deve contenere il cognome';
   else if( window.dataNascita && $selector.val().toLowerCase().search( dataNascita ) > -1 )
    return 'La password non deve contenere la data di nascita';
   else if( window.dataNascita2 && $selector.val().toLowerCase().search( dataNascita2 ) > -1 )
    return 'La password non deve contenere la data di nascita';
   else if( window.dataNascita3 && $selector.val().toLowerCase().search( dataNascita3 ) > -1 )
    return 'La password non deve contenere la data di nascita';
   else if( window.dataNascita4 && $selector.val().toLowerCase().search( dataNascita4 ) > -1 )
    return 'La password non deve contenere la data di nascita';
   else if( window.dataNascita5 && $selector.val().toLowerCase().search( dataNascita5 ) > -1 )
    return 'La password non deve contenere la data di nascita';
   else if( window.dataNascita6 && $selector.val().toLowerCase().search( dataNascita6 ) > -1 )
    return 'La password non deve contenere la data di nascita';
   else if( window.dataNascita7 && $selector.val().toLowerCase().search( dataNascita7 ) > -1 )
    return 'La password non deve contenere la data di nascita';
  },
  all: function( $selector ) {
   return R.fun.rulesValidation.password.req( $selector ) || R.fun.rulesValidation.password.val( $selector ) || R.fun.rulesValidation.password.len( $selector ) || R.fun.rulesValidation.password.val2( $selector ) || R.fun.rulesValidation.password.val3( $selector ) || R.fun.rulesValidation.password.val4( $selector ) || R.fun.rulesValidation.password.val5( $selector );
  }
 },

 repassword: {
  req: function( $selector ) {
   return $selector.val() ? '' : 'Ripetere la password';
  },
  val: function( $selector ) {
   var password = $( 'form#formValidate input#password' ).size() ? $( 'form#formValidate input#password' ).val() : '';
   return ( $selector.val() == password )? '' : 'La password non coincide';
  },
  all: function( $selector ) {
   return R.fun.rulesValidation.repassword.req( $selector ) || R.fun.rulesValidation.repassword.val( $selector );
  }
 }

};

// Attiva il pulsante di invio #btn-submit se il form #formValidate è convalidato
R.fun.formValidate = function( init ) {
 if( $( 'form#formValidate' ).size() ) {
  var $form = $( 'form#formValidate' );
  $( '#btn-submit', $form ).attr( 'disabled', 'disabled' );
  $( '#btn-submit', $form ).removeClass("btn-invia-registration").addClass("btn-invia-inattivo");
  var esit = '';
  var fields = ['accettazioneTrattamentoDati', 'codiceFiscale', 'username', 'password', 'repassword'];

  $.each( fields, function( index, value ) {
   if( $( 'input#' + value, $form ).size() )
    esit = esit || R.fun.rulesValidation[value].all( $( 'input#' + value, $form ) );
  } );

  if( esit ) {
   $( '#btn-submit', $form ).attr( 'disabled', 'disabled' );
   $( '#btn-submit', $form ).removeClass("btn-invia-registration").addClass("btn-invia-inattivo");
  }else{
   $( '#btn-submit', $form ).removeAttr( 'disabled' );
   $( '#btn-submit', $form ).removeClass("btn-invia-inattivo").addClass	("btn-invia-registration");
  }
 }
};

$('#accettazioneTrattamentoDati').on( 'blur', function() {
	var $form = $( 'form#formValidate' );
	$( '.tooltip[data-href=#usernameAlter]', $form ).removeClass( 'active' );
   } );

// Attiva i controlli on-the-fly sui singoli campi di input
R.fun.fieldsValidate = function( init ) {
 if( $( 'form#formValidate' ).size() ) {
  var $form = $( 'form#formValidate' );

  if( $( 'input#accettazioneTrattamentoDati', $form ).size() ) {
   $( 'input#accettazioneTrattamentoDati', $form ).on( 'change', function() {
    R.fun.formValidate();
   } );
  }

  if( $( 'input#codiceFiscale', $form ).size() ) {
   $( 'input#codiceFiscale', $form ).on( 'focus keyup keydown mousedown', function() {
    var esit = R.fun.rulesValidation.codiceFiscale.all( $( this ) );
    $( this ).removeClass( 'error' ).addClass( esit ? 'error' : '' );
    $( '.error-mesg', $( '#Rcf' ) ).remove();
    $( '#Rcf', $form ).prepend( esit ? '<p class="error-mesg"><span class="ico-error">' + esit + '</span></p>' : '' );
    R.fun.formValidate();
   } );
  }

  if( $( 'input#username', $form ).size() ) {
   $( 'input#username', $form ).on( 'focus keyup keydown', function() {
    var esit = R.fun.rulesValidation.username.all( $( this ) );
    $( this ).removeClass( 'error' ).addClass( esit ? 'error' : '' );
    $( '.tooltip[data-href=#usernameAlter]', $form ).removeClass( 'active' );
    $( '.error-mesg', $( '#Rusr' ) ).remove();
    $( '#Rusr', $form ).prepend( esit ? '<p class="error-mesg"><span class="ico-error">' + esit + '</span></p>' : '' );
    R.fun.formValidate();
   } );

   $( 'input#username', $form )
   .on( 'focus keyup keydown', function() {
    $( '#Rusr1', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.username.len( $( this ) ) ? '' : 'success' );
    $( '#Rusr2', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.username.val2( $( this ) ) ? '' : 'success' );
    $( '#Rusr3', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.username.val( $( this ) ) ? '' : 'success' );
    R.fun.formValidate();
   } )
   .on( 'focus', function() {
    $( '.tooltip[data-href=#username]', $form ).addClass( 'active' );
    R.fun.formValidate();
   } )
   .on( 'blur', function() {
    $( '.tooltip[data-href=#username]', $form ).removeClass( 'active' );
    R.fun.formValidate();
   } );
  }

  if( $( 'input#password', $form ).size() ) {
   $( 'input#password', $form ).on( 'focus keyup keydown', function() {
    var esit = R.fun.rulesValidation.password.all( $( this ) );
    $( this ).removeClass( 'error' ).addClass( esit ? 'error' : '' );
    $( '.error-mesg', $( '#Rpwd' ) ).remove();
    $( '#Rpwd', $form ).prepend( esit ? '<p class="error-mesg"><span class="ico-error">' + esit + '</span></p>' : '' );
    R.fun.formValidate();
   } );

   $( 'input#password', $form )
   .on( 'focus keyup keydown', function() {
    $( '#Rpwd1', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.password.len( $( this ) ) ? '' : 'success' );
    $( '#Rpwd2', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.password.val2( $( this ) ) ? '' : 'success' );
    $( '#Rpwd3', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.password.val3( $( this ) ) ? '' : 'success' );
    $( '#Rpwd4', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.password.val4( $( this ) ) ? '' : 'success' );
    $( '#Rpwd5', $form ).removeClass( 'success' ).addClass( R.fun.rulesValidation.password.val5( $( this ) ) ? '' : 'success' );
    R.fun.formValidate();
   } )
   .on( 'focus', function() {
    $( '.tooltip[data-href=#password]', $form ).addClass( 'active' );
    R.fun.formValidate();
   } )
   .on( 'blur', function() {
    $( '.tooltip[data-href=#password]', $form ).removeClass( 'active' );
    R.fun.formValidate();
   } );
  }

  if( $( 'input#repassword', $form ).size() ) {
   $( 'input#repassword', $form ).on( 'focus keyup keydown', function() {
    var esit = R.fun.rulesValidation.repassword.all( $( this ) );
    $( this ).removeClass( 'error' ).addClass( esit ? 'error' : '' );
    $( '.error-mesg', $( '#Rrpwd' ) ).remove();
    $( '#Rrpwd', $form ).prepend( esit ? '<p class="error-mesg"><span class="ico-error">' + esit + '</span></p>' : '' );
    R.fun.formValidate();
   } );
  }

 }
};

// Decide se avviare il tutorial
// Ad esempio, si può decidere di avviare il tutorial quando nella pagina è definita la variabile:
// utente = 'Nome Cognome';
R.fun.firstAccess = function(nomeCognome) {
 //var check = window.utente ? window.utente : false;

 if( true )
  R.fun.tutorial(nomeCognome);
};

// Il tutorial
R.fun.tutorial = function(nomeCognome) {

 // Fix - Individua un selettore univoco per il tutorial 4- Punto vendita (aside)
 $( '#main > aside.sidebar > .select-skinned' ).wrap( $( '<div>', { id: 'Rtutorial4' } ) );

 // Fix - Individua un selettore univoco per il tutorial 5- Cruscotto
 $( 'aside.sidebar #full-profile' ).nextAll().wrapAll( $( '<div>', { id: 'Rtutorial5' } ) );

 // Crea un livello di overlay
 if( $( '#overlay.R' ).size() == 0 ) {
  $( '<div>', { id: 'overlay', 'class': 'R' } ).appendTo( $( 'body' ) );
  window.scrollTo( 0, 0 );
  $( 'html' ).css( { overflow: 'hidden' } );
 }

 var idBp = "";

 // Tutorial Welcome
 var content = '<div class="title">' +
               '<p class="close"><a href="#close"></a></p>' +
               '</div>' +
               '<div class="content">' +
               '<p>Benvenuto <strong>' + nomeCognome + '</strong></p>' +
               '<div class="textFromFile" data-filepath="/priv/tutorialInfo.xml" data-selector="messaggi[name=\'tutorialWelcome\'] messaggio">name="tutorialWelcome"</div>' +
               '<div style="width:90px;margin:auto;"><p class="button"><a href="#tutorial1" class="btn-invia-registration" style="cursor:pointer;"><span class="ico-gt">INIZIA</span></a></p></div>' +
               '<p class="link"><a href="#close">Salta il tutorial</a></p>' +
               '</div>';
 $( '<div>', { id: 'welcome-t', 'class': 'R' } )
 .append( $( '<div>', { id: 'welcome-c', 'class': 'R' } )
  .append( $( '<div>', { id: 'welcome', 'class': 'R', html: content } ) )
 ).appendTo( $( 'body' ) );

 // Tutorial 1- Ordini
 var content = '<p class="close"><a href="#close"></a></p>' +
               '<h1 class="title">Ordini</h1>' +
               '<div class="content">' +
               '<div class="textFromFile" data-filepath="/priv/tutorialInfo.xml" data-selector="messaggi[name=\'tutorialOrdini\'] messaggio">name="tutorialOrdini"</div>' +
               '</div>' +
               '<p class="buttom left"><span class="hi"></span> <span></span> <span></span> <span></span> <span></span></p>' +
               '<p class="buttom right"><a href="#tutorial2">Continua</a></p>';
 $( '<div>', { id: 'tutorial1', 'class': 'tutorial top R', html: content } ).appendTo( $( '#ordini' ) ).hide();

 // Tutorial 2- Contabilità
 var content = '<p class="close"><a href="#close"></a></p>' +
               '<h1 class="title">Contabilit&agrave;</h1>' +
               '<div class="content">' +
               '<div class="textFromFile" data-filepath="/priv/tutorialInfo.xml" data-selector="messaggi[name=\'tutorialContabilita\'] messaggio">name="tutorialContabilita"</div>' +
               '</div>' +
               '<p class="buttom left"><span></span> <span class="hi"></span> <span></span> <span></span> <span></span></p>' +
               '<p class="buttom right"><a href="#tutorial3">Continua</a></p>';
 $( '<div>', { id: 'tutorial2', 'class': 'tutorial top R', html: content } ).appendTo( $( '#rendicontazione' ) ).hide();

 // Tutorial 3- Punto vendita
 var content = '<p class="close"><a href="#close"></a></p>' +
               '<h1 class="title">Punto vendita</h1>' +
               '<div class="content">' +
               '<div class="textFromFile" data-filepath="/priv/tutorialInfo.xml" data-selector="messaggi[name=\'tutorialPDV\'] messaggio">name="tutorialPDV"</div>' +
               '</div>' +
               '<p class="buttom left"><span></span> <span></span> <span class="hi"></span> <span></span> <span></span></p>' +
               '<p class="buttom right"><a href="#tutorial4">Continua</a></p>';
 $( '<div>', { id: 'tutorial3', 'class': 'tutorial top R', html: content } ).appendTo( $( '#punto-vendita' ) ).hide();

 // Tutorial 4- Punto vendita (aside)
 var content = '<p class="close"><a href="#close"></a></p>' +
               '<h1 class="title">Seleziona punto vendita</h1>' +
               '<div class="content">' +
               '<div class="textFromFile" data-filepath="/priv/tutorialInfo.xml" data-selector="messaggi[name=\'tutorialPDVspalla\'] messaggio">name="tutorialPDVspalla"</div>' +
               '</div>' +
               '<p class="buttom left"><span></span> <span></span> <span></span> <span class="hi"></span> <span></span></p>' +
               '<p class="buttom right"><a href="#tutorial5">Continua</a></p>';
 $( '<div>', { id: 'tutorial4', 'class': 'tutorial left R', html: content } ).appendTo( $( '#Rtutorial4' ) ).hide();

 // Tutorial 5- Cruscotto
 var content = '<p class="close"><a href="#close"></a></p>' +
               '<h1 class="title">Info Rapide</h1>' +
               '<div class="content">' +
               '<div class="textFromFile" data-filepath="/priv/tutorialInfo.xml" data-selector="messaggi[name=\'tutorialCruscotto\'] messaggio">name="tutorialCruscotto"</div>' +
               '</div>' +
               '<p class="buttom left"><span></span> <span></span> <span></span> <span></span> <span class="hi"></span></p>' +
               '<p class="buttom right"><a href="#close">Continua</a></p>';
 $( '<div>', { id: 'tutorial5', 'class': 'tutorial left R', html: content } ).appendTo( $( '#Rtutorial5' ) ).hide();

 // Gestione della chiusura del totorial
 $( 'body' ).on( 'click', 'a[href="#close"]', R.fun._close = function( ev ) {
  ev.preventDefault();
  $( 'html' ).css( { overflow: '' } );
  $( '#overlay.R, #welcome-t.R, .tutorial.R, #freeze.R' ).remove();
  $( 'nav' ).css( { 'position': '' } );
  $( 'nav ul li .secondLiv' ).css( { top: '' } );
  $( '#menu-focus' ).css( { top: '' } );
  $( '#ordini, #rendicontazione, #punto-vendita, #Rtutorial4, #Rtutorial5' ).removeClass( 'hi' );
  $( 'html, body' ).animate( { scrollTop: 0 }, 'slow' );
 } );

 // Gestione step by step (click)
 $( document )
 .on( 'click', 'a[href="#tutorial1"]', R.fun._click1 = function( ev ) {
  ev.preventDefault();
  $( '#welcome-t' ).remove();
  $( 'nav' ).css( { 'position': 'static' } );
  $( 'nav ul li .secondLiv' ).css( { top: '-10000px' } );
  $( '#menu-focus' ).css( { top: '-10000px' } );
  $( '#ordini' ).addClass( 'hi' );
  $( '#tutorial1' ).show();
 } )
 .on( 'click', 'a[href="#tutorial2"]', R.fun._click2 = function( ev ) {
  ev.preventDefault();
  $( '#tutorial1' ).remove();
  $( '#ordini' ).removeClass( 'hi' );
  $( '#rendicontazione' ).addClass( 'hi' );
  $( '#tutorial2' ).show();
 } )
 .on( 'click', 'a[href="#tutorial3"]', R.fun._click3 = function( ev ) {
  ev.preventDefault();
  $( '#tutorial2' ).remove();
  $( '#rendicontazione' ).removeClass( 'hi' );
  $( '#punto-vendita' ).addClass( 'hi' );
  $( '#tutorial3' ).show();
 } )
 .on( 'click', 'a[href="#tutorial4"]', R.fun._click4 = function( ev ) {
  ev.preventDefault();
  $( '#tutorial3' ).remove();
  $( '#punto-vendita' ).removeClass( 'hi' );
  $( '#Rtutorial4' ).addClass( 'hi' );
  $( '#Rtutorial4' ).closest( '.select-skinned' ).append( $( '<div>', { 'id': 'freeze', 'class': 'R' } ) );
  $( '#tutorial4' ).show();
  // Fix - Qualcosa inibisce i click sul tutorial 4 e le callback vanno riagganciate
  $( 'a[href="#tutorial5"]' ).on( 'click', R.fun._click5 );
  $( 'a[href="#close"]' ).on( 'click', R.fun._close );
 } )
 .on( 'click', 'a[href="#tutorial5"]', R.fun._click5 = function( ev ) {
  ev.preventDefault();
  $( '#tutorial4' ).remove();
  $( '#Rtutorial4' ).removeClass( 'hi' );
  $( '#Rtutorial5' ).addClass( 'hi' );
  $( '#freeze.R' ).remove();
  $( '#Rtutorial5' ).append( $( '<div>', { 'id': 'freeze', 'class': 'R' } ) );
  $( 'html, body' ).animate( { scrollTop: $( '#Rtutorial5' ).position().top }, 'slow', function() {
   $( '#Rtutorial4' ).closest( '.select-skinned' ).css( { 'z-index': '-1 !important' } );
   $( '#tutorial5' ).show();
  } );
  // Fix - Qualcosa inibisce i click sul tutorial 5 e la callback va riagganciata
  $( 'a[href="#close"]' ).on( 'click', R.fun._close );
 } );
};

R.fun.eshop = function() {

 if( $( '#eshop' ).size() ) {
  var $eshop = $( '#eshop' );

  $( '#eshop .product.right' ).after( $( '<div>', { 'class': 'j cl' } ) );

  // Accordion
  $( '.acc > .title', $( eshop ) ).on( 'click', function( ev ) {
   ev.preventDefault();
   $( this ).closest( '.acc' ).toggleClass( 'off' );
  } );

  $( '#eshop .product .amount input[type=text]' ).each( function( i, e ) {
   $( e ).after( $( '<a>',  { href: '#', 'class': 'sel' } ) );
  } );
 }

};

$( document ).ready( function() {
 R.fun.fieldsValidate();
 R.fun.formValidate();
 //R.fun.firstAccess();
 R.fun.eshop(); 
} );