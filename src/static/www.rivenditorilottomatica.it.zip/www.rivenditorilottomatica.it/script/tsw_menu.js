$(function(){
	jQuery("#amplia-il-tuo-business").click(
		function(){
			action_SC_Extends('navigate', 'Amplia il tuo Business', 'Step Dati Anagrafici', this); return false;
		}
	);
});