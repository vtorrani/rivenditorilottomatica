//Click sul pulsante Login Area Privati
var sgi_user = "lttmtcrivenditoripro";
var idpos 	= "";
var idbp 	= "";

$(function(){
	idpos 	= $('#psCombo').data('idpos');
	idbp 	= $('#psCombo').data('idbp');
});

function overridePageName(s, newPageName, args){
	var func 		= s.tl;
	var oldPageName = s.pageName;
	
	pageNameSc 							= pageNameSc.split(' : ');
	pageNameSc[pageNameSc.length - 1] 	= newPageName;
	pageNameSc 							= pageNameSc.join(' : ');
	s.pageName 							= s.server + ' : ' + pageNameSc;
	
	// imposto 10 eventuali parametri (non sono obbligatori)
	s.tl(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10]);
	
	s.pageName = oldPageName;
}

//Aggiunto da Roberto 
function action_SC_Click_Chat_Step1() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop48,eVar10,events";
	s.linkTrackEvents="event11";
	s.prop48="apertura chat - step 1";
	s.eVar10=s.prop48;
	s.events="event11";
	s.tl(this,'o','apertura chat');
}

function action_SC_Click_Chat_Step2() {
		var s=s_gi(sgi_user);
		s.linkTrackVars="prop48,eVar10,events";
		s.linkTrackEvents="event11";
		s.prop48="apertura chat - step 2";
		s.eVar10=s.prop48;
		s.events="event11";
		s.tl(this,'o','apertura chat');}
//--------------------------------




function action_SC_Login_AP() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop2";
	s.linkTrackEvents="None";
	s.prop2="Login";
	s.tl(this,'o','Login');
}

function action_SC_Reset_PW(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop3";
	s.linkTrackEvents="None";
	s.prop3="Reset Password";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Reset Password', null, FunctionSC);
}

function action_SC_Request_Credentials() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop3,events";
	s.linkTrackEvents="event2";
	s.prop3="Richiesta Credenziali";
	s.events="event2";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(this,'o','Richiesta Credenziali',null, 'navigate');
}

function action_SC_Credentials_Success() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="events";
	s.linkTrackEvents="event22";
	s.events="event22";
	s.tl(this,'o','Registrazione');
}

function action_SC_Download(Type, Name) {
	
	var sub = pathname.substring(0,pathname.length-5);
	var split= sub.split('/');
	var idPage = split[split.length-1];
	
	if(idPage=='tecnica'){
		idPage='AssistenzaTecnica';
	}else if (idPage=='home'){
		idPage='AssistenzaTecnica';
	}
	
	
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop4,eVar3,events";
	s.linkTrackEvents="event3";
	s.prop4=idPage+" - "+Name;
	s.eVar3=idPage;
	s.events="event3";
	s.tl(this,'o','Download Documenti');
	
}

function action_SC_Link(Name) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop6";
	s.linkTrackEvents="None";
	s.prop6=Name;
	s.tl(true,'o','Link Slider');
}

function action_SC_Open_Slide(NameGo) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop5";
	s.linkTrackEvents="None";
	s.prop5=NameGo;
	s.tl(true,'o','Link Open Slider');
}

function action_SC_Close_Slide(NameGc) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop5";
	s.linkTrackEvents="None";
	s.prop5=NameGc;
	s.tl(true,'o','Link Close Slider');
}

function action_SC_Tab(Name) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop7";
	s.linkTrackEvents="None";
	s.prop7=s.pageName+":"+Name;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(this,'o','Tab di navigazione',null, 'navigate');
}

function action_SC_Bookkeeper_Research(Service, TypeDoc, Date, ResultSize) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop8,prop9,prop32,prop33";
	s.linkTrackEvents="None";
	s.prop8="Ricerca documento contabile";
	s.prop9=Service+"|"+TypeDoc;
	s.prop32=Date;
	s.prop33=ResultSize;
	s.tl(true,'o','Ricerca Doc Contabile');
}

function action_SC_Message_Center(FunctionSC, TypeMs, IdMs, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop10,prop35";
	s.linkTrackEvents="None";
	s.prop10=TypeMs;
	s.prop35=IdMs;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Centro Messaggi', null, FunctionSC);
}


//SearchResults
function action_SC_Calendar_Selection(TypeCs, ActionCs) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop14,prop15";
	s.linkTrackEvents="None";
	s.prop14=TypeCs.toLowerCase();
	s.prop15=ActionCs;
	s.tl(this,'o','Calendario');
}

function action_SC_Suggested(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop16";
	s.linkTrackEvents="None";
	s.prop16=s.pageName;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Invio Suggerimento', null, FunctionSC);
}

function action_SC_Participates(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop16";
	s.linkTrackEvents="None";
	s.prop16="Hai un suggerimento";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Invio Suggerimento', null, FunctionSC);
}

function action_SC_Sends_Participates(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop16";
	s.linkTrackEvents="None";
	s.prop16="Invia Suggerimento - Partecipa";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Invio Suggerimento', null, FunctionSC);
}

function action_SC_Comments(Area, FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop17";
	s.linkTrackEvents="None";
	s.prop17=Area;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Commento Suggerimento', null, FunctionSC);
}

function action_SC_Assistance_Request(TypeRa, What, Contact, FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop18,prop19,prop20";
	s.linkTrackEvents="None";
	s.prop18=TypeRa;
	s.prop19=What;
	s.prop20=Contact;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Richiesta di Assistenza', null, FunctionSC);
}

function action_SC_Phone_Assistance(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop18";
	s.linkTrackEvents="None";
	s.prop18="Box Assistenza Telefonica";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Richiesta di Assistenza', null, FunctionSC);
}

function action_SC_Sends_Survey(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop21";
	s.linkTrackEvents="None";
	s.prop21="Risposta Sondaggio - Home Page Privata";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Risposta Sondaggio', null, FunctionSC);
}

function action_SC_Participates_Response(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop21";
	s.linkTrackEvents="None";
	s.prop21="Risposta Sondaggio - Partecipa";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Risposta Sondaggio', null, FunctionSC);
}

function action_SC_Proposed_Survey(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop22";
	s.linkTrackEvents="None";
	s.prop22="Proposta Sondaggio";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Proposta Sondaggio', null, FunctionSC);
}

function action_SC_Sends_Proposed(FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop22";
	s.linkTrackEvents="None";
	s.prop22="Invia Proposta Sondaggio";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Proposta Sondaggio', null, FunctionSC);
}

function action_SC_Link_A(TitleLink, ContestSC) {
	var sub = pathname.substring(0,pathname.length-5);
	var split= sub.split('/');
	var idPage = split[split.length-1];
	
	if (idPage=='home'){
		idPage='tecnica';
	}

	var s=s_gi(sgi_user);
	s.linkTrackVars="prop24";
	s.linkTrackEvents="None";
	s.prop24=idPage+" - "+TitleLink;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Content Links',null, 'navigate');
}

function action_SC_Link_Ex(TitleLink) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop25";
	s.linkTrackEvents="None";
	s.prop25=TitleLink;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(this,'o','Link Esterni',null, 'navigate');
}

function action_SC_Print_Att(NameFile,FunctionSC, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop26";
	s.linkTrackEvents="None";
	s.prop26=NameFile;
	s.forcedLinkTrackingTimeout=2000;
	if(ContestSC==undefined){
		ContestSC=this;
		FunctionSC=function(){javascript:window.print(); };
	}
	s.tl(ContestSC,'o','Stampa PDF-HTML',null, FunctionSC);
}

function action_SC_Download_Att(NameDownload) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop27";
	s.linkTrackEvents="None";
	s.prop27=NameDownload;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(this,'o','Download Allegati',null, 'navigate');
}

function action_SC_Extends(FunctionSC, NameType, NameStep, ContestSC) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop28,prop29";
	s.linkTrackEvents="None";
	s.prop29=NameType;
	s.prop28=NameStep;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(ContestSC,'o','Step Diventa/Amplia Business', null, FunctionSC);
}

function action_SC_Dunning(FunctionSC,TypeButton) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop34";
	s.linkTrackEvents="None";
	s.prop34=TypeButton;
	s.forcedLinkTrackingTimeout=2000;
	s.tl(true,'o','Sollecito', null, FunctionSC);
}

function action_SC_Click_Chat() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop48,eVar10,events";
	s.linkTrackEvents="event11";
	s.prop48="chat aperta|chat chiusa";
	s.eVar10=s.prop48;
	s.events="event11";
	s.tl(this,'o','apertura chat');
}

function action_SC_Click_PayNow() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop51,prop70,eVar13,eVar36,events";
	s.linkTrackEvents="event14,event37";
	s.prop70="step1 - paga ora";
	s.eVar36=s.prop70;
	s.prop51="mybank";
	s.eVar13=s.prop51;
	s.events="event14,event37";
	s.tl(this,'o','paga ora insoluti');
}

function action_SC_Click_MyBankSteps(numStep) {
	var s=s_gi(sgi_user);
	var labelStep = ""
	if (numStep == 2){
		labelStep = "step2 riepilogo pagamento - conferma";
	}
	if (numStep == 3){
		labelStep = "step3 scelta banca - procedi";
	}
	s.linkTrackVars="prop70,eVar36,events";
	s.linkTrackEvents="event37";
	s.prop70=labelStep;
	s.eVar36=s.prop70;
	s.events="event37";
	s.tl(this,'o','step pagamento insoluti mybank');
}

function action_SC_MyBankResult(idTransaction,esitoReturn) {
	var s=s_gi(sgi_user);
	s.events="event15";
	s.prop52="transazione "+esitoReturn;
	s.eVar14=s.prop52;
	s.prop53=""+idTransaction;
	s.eVar15=s.prop53;
	s.prop47=idBp;
	s.eVar2=s.prop47;
	s.prop23=""+jQuery("#psCombo option:selected").val();
	s.eVar4=s.prop23;
	s.prop36="P.IVA";
	s.eVar5=s.prop36;
}

// Start action for cookie
function action_SC_OpWin_Cookie() {
	var pageName = ""+location.pathname.split(/[?#]/)[0];
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop30,eVar30';
	s.linkTrackEvents='event5';
	s.prop30= pageName+" : cookie : modale";
	s.events='event5';
	s.eVar30=s.prop30;
	s.tl(this,'o','Modale Cookie Display');
}

function action_SC_Accept_Cookie() {
	var pageName = ""+location.pathname.split(/[?#]/)[0];
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop30,eVar30';
	s.linkTrackEvents='event6';
	s.prop30=pageName+" : cookie : modale";
	s.events='event6';
	s.eVar30=s.prop30;
	s.tl(this,'o','Modale Cookie OK');
}
// Stop action for cookie

function action_SC_Click_Ultimo_Ordine(ordine){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop57,eVar22,events';
	s.linkTrackEvents='event24';
	s.prop57=ordine;
	s.eVar22=s.prop57;
	s.events='event24';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	
//	s.tl(this,'o','ultimo ordine'); 
	overridePageName(s, 'popup_ultimo_ordine', [this,'o','ultimo ordine']);
}

function action_SC_Click_Ordine_Preferito(ordine){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop69,eVar35,events';
	s.linkTrackEvents='event38';
	s.prop69=ordine; 
	s.eVar35=s.prop69;
	s.events='event38';
//	s.tl(this,'o','visualizzazione ordine preferito');

	overridePageName(s, 'popup_ordine_preferito', [this,'o','visualizzazione ordine preferito']);
}

function action_SC_Click_Aggiungi_Ultimo_Ordine(ordine, tab){
	var s=s_gi(sgi_user);
	s.linkTrackVars='eVar43,prop23,eVar4,prop47,eVar2,prop58,eVar23,events';
	s.linkTrackEvents='event25';
	s.prop58=ordine; 
	s.eVar23=s.prop58;
	s.events='event25';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.eVar43=tab.toLowerCase();
	s.tl(this,'o','carrello gev da ultimo ordine');
}

function action_SC_Click_Salva_Ordine_Preferito(ordine){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop59,eVar24,events';
	s.linkTrackEvents='event26';
	s.prop59=ordine;
	s.eVar24=s.prop59;
	s.events='event26';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','salvataggio ordine preferito');
}

function action_SC_Click_Aggiungi_Ordine_Preferito(ordine){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop60,eVar26,events';
	s.linkTrackEvents='event27';
	s.prop60=ordine; 
	s.eVar26=s.prop60;
	s.events='event27';
	s.tl(this,'o','carrello gev da ordine preferito');
}

//CALL DEF
function action_SC_Click_SpedizioniGEV() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop37,eVar7,events";
	s.linkTrackEvents="event7";
	s.prop37="monitoraggio spedizioni gev";
	s.eVar7=s.prop37;
	s.events="event7";
	s.tl(this,'e','monitoraggio spedizioni gev');
}

function action_SC_Click_SpedizioniMDC() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop38,eVar8,events";
	s.linkTrackEvents="event8";
	s.prop38="monitoraggio spedizioni mdc";
	s.eVar8=D="c8"; //s.eVar8=s.prop38;
	s.events="event8";
	s.tl(this,'e','monitoraggio spedizioni mdc');
}

function action_SC_Click_VerificaTransazioni(macroservizio, tiposervizio, servizio, idtrans) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop39,eVar6,events";
	s.linkTrackEvents="event9";
	s.prop39=""+macroservizio+"-"+tiposervizio+"-"+servizio+"-"+idtrans;
	s.eVar6=s.prop39;
	s.events="event9";
	s.tl(this,'o','verifica transazioni');
}

function action_SC_Click_VerificaVincite(gioco,datada,dataa,codice) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop40,eVar9,events";
	s.linkTrackEvents="event10";
	s.prop40=""+gioco+"�"+datada+"_"+dataa+"-"+codice;
	s.eVar9=s.prop40;
	s.events="event10";
	s.tl(this,'o','verifica vincite');
}

function action_SC_Click_TabAddebiti() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop49,eVar11,events";
	s.linkTrackEvents="event12";
	s.prop49="tab addebiti insoluti";
	s.eVar11=s.prop49;
	s.events="event12";
	s.tl(this,'o','tab addebiti insoluti');
}

function action_SC_Click_AccordionAddebiti() {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop50,eVar12,events";
	s.linkTrackEvents="event13";
	s.prop50="ID addebito";
	s.eVar12=s.prop50;
	s.events="event13";
	s.tl(this,'o','accordion addebiti');
}

// 04/05/2016
//Click sul pulsante "Vai agli ordini GeV"
function action_SC_Click_VaiOrdiniGev(ordine, FunctionSC){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop71,eVar12,events';
	s.linkTrackEvents='event40';
	s.prop71=ordine;
	s.eVar12=s.prop71;
	s.events='event40';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','carrello gev da magazzino', null, FunctionSC);
}


//Click sul pulsante "Aggiungi al carrello"
//function action_SC_Click_AggiungiAlCarrello(ordine){
//	var s=s_gi(sgi_user);
//	s.linkTrackVars='prop50,eVar15,events';
//	s.linkTrackEvents='event16';
//	s.prop50=ordine;
//	s.eVar15=s.prop50;
//	s.events='event16';
//	s.prop47=idbp;
//	s.eVar2=s.prop47;
//	s.prop23=idpos;
//	s.eVar4=s.prop23;
//	s.tl(this,'o','carrello gev da stock');
//}
	

//Click sul pulsante "Download schermata stock"
function action_SC_Click_DownloadStock(ordine, FunctionSC){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop72,eVar16,events';
	s.linkTrackEvents='event17';
	s.prop72='schermata stock - ' + ordine;
	s.eVar16=s.prop72;
	s.events='event17';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','download schermata stock', null, FunctionSC);
}

//Click sul pulsante "Stampa schermata stock"
function action_SC_Click_StampaStock(ordine, FunctionSC){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop73,eVar17,events';
	s.linkTrackEvents='event41';
	s.prop73='schermata stock - ' + ordine;
	s.eVar17=s.prop73;
	s.events='event41';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','stampa schermata stock', null, FunctionSC);
}


//Click sul pulsante "Annulla selezioni nello stock"
function action_SC_Click_AnnullaSelezioniStock(ordine){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop54,eVar19,events';
	s.linkTrackEvents='event20';
	s.prop54=ordine;
	s.eVar19=s.prop54;
	s.events='event20';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','stock - annulla selezioni');
}

//Lotto: Sezione informativa
//Visualizzazione contenuto Starter KIT (Click su "Vedi Contenuto KIT")
function action_SC_Click_Lotto_Contenuto_Starter_Kit(){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop62,eVar28,events';
	s.linkTrackEvents='event29';
	s.prop62='lotto - visualizzazione starter kit'; 
	s.eVar28=s.prop62;
	s.events='event29';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','lotto - visualizza starter kit');
}

//Tracking pacco
function action_SC_Click_Lotto_Tracking_Pacco(){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop63,eVar29,events';
	s.linkTrackEvents='event30';
	s.prop63='lotto - tracking spedizione starter kit'; 
	s.eVar29=s.prop63;
	s.events='event30';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'e','lotto - tracking spedizione starter kit');
}

//Visualizzazione delle foto della dotazione tecnica
function action_SC_Click_Lotto_Visualizzazione_Foto_Dotazione_Tecnica(title){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop64,eVar30,events';
	s.linkTrackEvents='event31';
	s.prop64=title; 
	s.eVar30=s.prop64;
	s.events='event31';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','lotto - visualizzazione foto dotazione');
}
	
//Accesso al Questionario post vista del tecnico
function action_SC_Click_Lotto_Questionario_Post_Vista_Tecnico(){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop65,eVar31,events';
	s.linkTrackEvents='event32';
	s.prop65='lotto - questionario soddisfazione visita tecnico'; 
	s.eVar31=s.prop65;
	s.events='event32';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','lotto - questionario soddisfazione visita tecnico');
}
//END - Lotto: Sezione informativa

//Lotto: Sezione dedicata alla formazione
//Accesso al questionario (se non incluso nel tutorial della formazione)
function action_SC_Click_Lotto_Questionario(){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop68,eVar34,events';
	s.linkTrackEvents='event35';
	s.prop68='lotto - accesso questionario formazione';
	s.eVar34=s.prop68;
	s.events='event35';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','lotto - accesso questionario formazione');
}
	
//Download manuale (intero e singoli capitoli)
function action_SC_Click_Lotto_Download_Manuale(area, nome_capitolo){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop66,eVar32,events';
	s.linkTrackEvents='event33';
	s.prop66='lotto - area ' + area + ' - ' + (nome_capitolo || 'intero manuale'); 
	s.eVar32=s.prop66;
	s.events='event33';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'d','lotto - download manuale');
}
//END - Lotto: Sezione dedicata alla formazione

//Lotto: Sezione dedicata alle FAQ
//Clic per visualizzazione di ogni singola FAQ
function action_SC_Click_Lotto_FAQ(area, faq){
	var s=s_gi(sgi_user);
	s.linkTrackVars='prop67,eVar33,events';
	s.linkTrackEvents='event34';
	s.prop67=area + '_' + faq;
	s.eVar33=s.prop67;
	s.events='event34';
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	s.tl(this,'o','lotto - FAQ');
}
//END - Lotto: Sezione dedicata alle FAQ

// MDC - 27/12/2016
// START - Popup Click su Invio anticipato dell'ordine
function action_SC_Invio_Anticipato_Ordine_MDC(idOrdine){
	var s=s_gi(sgi_user); 
	s.linkTrackVars="prop75,eVar38,events";
	s.linkTrackEvents="event42";
	s.prop75=idOrdine;
	s.eVar38=D="c75"; //s.eVar38=s.prop75;
	s.events="event42";
	
	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	
	s.tl(this,'o','Invio anticipato mdc');
}
// END - Popup Click su Invio anticipato dell'ordine

function action_SC_Procedi_Ordine_MDC(popupShowed){
	var s=s_gi(sgi_user); 
	
	//s.clearVars();
	var pageName = 'Privato : mdc : procedi-ordine';
	if(popupShowed){
		pageName += '-popup';
	}
	
	s.pageName=pageName;
	void(s.t());
}

// Inserire il nome del bottone: "Chiudi" (X) , "Torna al catalogo", "Procedi all'ordine", "Conferma l'ordine"
function action_SC_Interazioni_Ordini_MDC(buttonName){
	var s=s_gi(sgi_user); 
	s.linkTrackVars="eVar39,events";
	s.linkTrackEvents="event43";
	s.eVar39=buttonName;
	s.events="event43";

	s.prop47=idbp;
	s.eVar2=s.prop47;
	s.prop23=idpos;
	s.eVar4=s.prop23;
	
	s.tl(this,'o','Interazioni ordini mdc');
}
// END - Popup Click su Invio anticipato dell'ordine
// END MDC - 27/12/2016

// Clic per download file statistiche lotto/del
function action_SC_Stampa_Statistiche_Lotto_DEL(section){
	var s=s_gi(sgi_user);
	s.linkTrackVars="eVar40,events";
	s.linkTrackEvents="event44";
	s.eVar40=section;
	s.events="event44";
	s.tl(this,'o','Stampa Estrazioni Lotto e 10eLotto');
}
// tracciamenti Performance
function action_SC_Click_RicercaTrend(gioco, tipoindicatore) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop23,eVar4,prop47,eVar2,eVar42,events";
	s.linkTrackEvents="event46";
	s.eVar42="statistiche vendite - selezione filtro "+gioco+" - "+tipoindicatore;
	s.events="event46";
	s.tl(this,'o','Interazioni statistiche vendite');
}

function action_SC_Click_TipoGrafico(tipo) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop23,eVar4,prop47,eVar2,eVar42,events";
	s.linkTrackEvents="event46";
	s.eVar42="statistiche vendite - grafico "+tipo;
	s.events="event46";
	s.tl(this,'o','Interazioni statistiche vendite');
}

function action_SC_Click_MeseDettaglio(mese) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop23,eVar4,prop47,eVar2,eVar42,events";
	s.linkTrackEvents="event46";
	s.eVar42="statistiche vendite - dettaglio mese "+mese;
	s.events="event46";
	s.tl(this,'o','Interazioni statistiche vendite');
}

function action_SC_Click_Suggest(elem) {
	var s=s_gi(sgi_user);
	s.linkTrackVars="prop23,eVar4,prop47,eVar2,eVar42,events";
	s.linkTrackEvents="event46";
	s.eVar42="statistiche vendite - click bottone "+elem;
	s.events="event46";
	s.forcedLinkTrackingTimeout=2000;
	s.tl(this,'o','Interazioni statistiche vendite');
}


//end

// GeV - 06/07/2017

// Banner catalogo GeV
function action_SC_Click_Banner_GeV(eVar41_value){
	var s=s_gi(sgi_user); 
	s.linkTrackVars="'prop23,eVar4,prop47,eVar2,eVar41,events";
	s.linkTrackEvents="event45";
	s.eVar41=eVar41_value;
	s.events="event45";
	s.tl(this,'o','Interazioni ordini gev');
}
// Scopri come ordinare
function action_SC_Click_Come_Ordinare(){
	s.pageName="Privato : gev : dettaglio scopri come ordinare";
	void(s.t());
}
// Popup lotteria catalogo GeV
function action_SC_Open_Popup_Lotteria(elemento){
	s.pageName="Privato : gev : dettaglio lotteria popup"
	s.events="event45"
	s.eVar41="gev-apertura da " + elemento;
	void(s.t());
}
// Aggiungi lotteria al carrello GeV
function action_SC_Aggiungi_Lotteria_Carrello(nomeLotteria){
	var s=s_gi(sgi_user); 
	s.linkTrackVars="eVar41,events";
	s.linkTrackEvents="event45";
	s.eVar41="gev-aggiunta al carrello " + nomeLotteria;
	s.events="event45";
	s.tl(this,'o','Interazioni ordini gev');
}
// Chiudi 'I più ordinati dagli altri rivenditori'
function action_SC_Chiudi_Consigliati(){
	var s=s_gi(sgi_user); 
	s.linkTrackVars="eVar41,events";
	s.linkTrackEvents="event45";
	s.eVar41="gev-layer i più ordinati - chiudi";
	s.events="event45";
	s.tl(this,'o','Interazioni ordini gev');
}
// Tab Ultimi e Penultimi ordini
function action_SC_Open_Tab_Ultimi_Ordini(tab){
	s.pageName="Privato : gev : popup_" + tab;
	s.server="Privato"
	s.channel="Privato : gev";
	s.events="event45";
	void(s.t());
}

//END GeV - 06/07/2017