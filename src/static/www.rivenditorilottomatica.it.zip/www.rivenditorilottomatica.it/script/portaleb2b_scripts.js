function submitFormSelection(formId, elementId, selectionId){
	var selection = $("#"+selectionId).val();	  	
	if(selection != 'default'){
		
		$("#"+elementId).val(selection);
    	$("#"+formId).submit();
		
	}

 }
 
 function showDiv(divToShow){
	
	 if($("#"+divToShow).is(':checked')){
	 $("#"+divToShow+"Div").show();
	 }else{
		 $("#"+divToShow+"Div").hide();
	 }	
 }
 
function showHiddenDiv(divToShow, divToHide){
	 
	 $("#"+divToShow).show();
	 $("#"+divToHide).hide();
	
 }
 
 function addInputFile(id){
	 var new_id = id+1;
	 $("#inputFileButton_"+id).html("<a href='#' onclick='removeInputFile("+id+")' >remove</a><br style='clear:both;' />");
	 $("#inputFileDiv").append("<input type='file' name='allegati'  value='$message.allegati' id='inputId_"+new_id+"' /><input type='hidden' value='on' name='_allegati' id='inputHiddenId_"+new_id+"' /><span id='inputFileButton_"+new_id+"' > <a href='#' onclick='addInputFile("+new_id+")'  >add</a></span>") ;
 }
 
 function removeInputFile(id){
 
	 $("#inputId_"+id).remove();
	 $("#inputHiddenId_"+id).remove();
	 $("#inputFileButton_"+id).remove();
 }
 
 function leaveFeedback(){
		
	var selection = $("#feedback").val();	  	
		
	$("#feedbackPoint").val(selection);
	$("#leaveFeedbackForm").submit();		

 }
 
 var displayDiv = 1;
 
function showHideDiv(divToShow){
	 
	 $("#div_"+divToShow).show();
	 $("#numberPage_"+divToShow).html("<a href='#' class='active' >"+divToShow+"</a>");
	 if(divToShow != displayDiv){
		 $("#div_"+displayDiv).hide();
		 $("#numberPage_"+displayDiv).html("<a href='#' onclick='showHideDiv("+displayDiv+")' >"+displayDiv+"</a>");
		 displayDiv = divToShow;
	 }
 }

var displayDivPagination = 1;

function showHideDivPagination(divToShow){
	 
	 $("#divPagination_"+divToShow).show();
	 $("#numberPagePagination_"+divToShow).html("<a href='#' class='active' >"+divToShow+"</a>");
	 if(divToShow != displayDivPagination){
		 $("#divPagination_"+displayDivPagination).hide();
		 $("#numberPagePagination_"+displayDivPagination).html("<a href='#' onclick='showHideDivPagination("+displayDivPagination+")' >"+displayDivPagination+"</a>");
		 displayDivPagination = divToShow;
	 }
}

function submitForm(formId, elementId, type){
	
	$("#"+elementId).val(type);
	$("#"+formId).submit();
}

function submitFormById(formId){
	
	$("#"+formId).submit();
}

function hideElement(elementId){
	
	$("#"+elementId).hide();
}

function selectPreferito(isPreferito){
	
	if(isPreferito == true){
		$("#preferitoDiv").html("<span class='star on' onclick='selectPreferito(false)'></span>");
	}else{
		$("#preferitoDiv").html("<span class='star' onclick='selectPreferito(true)'></span>");
	}
	 $("#preferito").val(isPreferito);
	 
}

$(function() {
	
    $( "#dataRichiestaCredenziali" ).datepicker();
    $( "#dataCambioStato" ).datepicker();    
    $( "#dataInizio" ).datepicker();    
    $( "#dataFine" ).datepicker();
    $( "#dataInizioAss" ).datepicker({ minDate: "-3M"});
    $( "#dataFineAss" ).datepicker({ minDate: "-3M"});
    
    $(".numeric").numeric();
	$(".integer").numeric(false, function() { alert("Inserire solo numeri interi"); this.value = ""; this.focus(); });
	$(".positive").numeric({ negative: false }, function() { alert("Valori negativi non ammessi"); this.value = ""; this.focus(); });
	$(".positive-integer").numeric({ decimal: false, negative: false }, function() { alert("Inserire solo numeri interi"); this.value = ""; this.focus(); });
	
    $(".priority").spinner({
    	min		: 1,
    	max		: 99999,
    	value	: 99999,
    	disabled: false
    })
    .change(
    	function(){
    		if($(this).val() <= 0){ 
    			$(this).val(1); 
    		}
    	}
    );
    
    $(".pajinate").each(
		function(index) {
			var _this = $(this);
			
			_this.pajinate({
				item_container_id 	: "#" + _this.attr("pajinate-content"),
				nav_panel_id 		: "#" + _this.attr("pajinate-pagination"),
				show_first_last		: false,
				nav_label_prev 		: '<',
				nav_label_next 		: '>',
				items_per_page 		: _this.attr("pajinate-items-per-page"),
				abort_on_small_lists: 'true',
				start_page 			: (_this.attr("pajinate-current-page") ? _this.attr("pajinate-current-page") : 0)
			});
		}
    );
    
    /*
	$(".pagContainer").pajinate({
		item_container_id 	: "#content",
		nav_panel_id 		: "#page_navigation",
		show_first_last		: false,
		nav_label_prev 		: '<',
		nav_label_next 		: '>',
		items_per_page 		: 5,
		abort_on_small_lists: 'true'
	});
    */
    
    if($(".categoriesSelect").size() != 0){
		$.ajax({
			type	: "POST",
			url		: "/portaleb2b/partecipa/rest/getCategories.do",
			success	: function(data) {
				$.each(data, function(index, categoria){
					$(".categoriesSelect").append("<option value='" + categoria.id + "'>" + categoria.categoria + "</option>");
				});
				$(".categoriesSelect").skinner({'width':'230px','maxitem':'4', reload:true});
			}
		});
	}
	
	if($(".categoriesSelectBO").size() != 0){
    	$.ajax({
    		type	: "POST",
    		url		: "/bob2b/partecipa/rest/getCategories.do",
    		success	: function(data) {
				$.each(data, function(index, categoria){
    				$(".categoriesSelectBO").append("<option value='" + categoria.id + "'>" + categoria.categoria + "</option>");
    			});
				$(".categoriesSelectBO").skinner({'width':'230px','maxitem':'4', reload:true});
    		}
    	});
    }
	
	if($.browser.msie && $.browser.version < 9){
		$('textarea[maxlength]').live('keyup change', function() {
			var str = $(this).val();
			var mx = parseInt($(this).attr('maxlength'));
			if (str.length > mx) {
				$(this).val(str.substr(0, mx));
				return false;
			}
		});
	}
	
	if($("div.emotional > div#visual").size() != 0){
		$("div.emotional > div#visual > div.rightArrow").each(
			function(index, rightArrow){
				setInterval(function(){
					$(rightArrow).trigger("click");
				}, 4000); // settato a 4 secondi
			}
		);
	}
	
	if($(".likePage").size() != 0){
		$(".likePage").each(
			function(index, like){
				_like = $(like);
				
				var paragraph = "<p class='likes'>";
				paragraph += "		<strong>" + _like.attr("data-text") + "</strong>";
				paragraph += "		<span class='sep20'></span>";
				paragraph += "		<span class='utile'></span>";
				paragraph += "	</p>";
				
				$(paragraph).appendTo(_like);
				
				$.ajax({
		    		type	: "POST",
		    		url		: "/portaleb2b/partecipa/rest/alreadyLikePage.do",
		    		data 	: {"pageURL" : window.location.href},
		    		success	: function(data) {
						if(data){
							var span_utile = _like.find(".utile");
							
							if(!data.alreadyLike){
								$("<a href='javascript: void(0);' class='service-button text' title='Utile'><span class='icon like'></span>Utile</a>")
								.click(
									function(){
										$.ajax({
											type	: "POST",
											url		: "/portaleb2b/partecipa/rest/likePage.do",
											data 	: {"pageURL" : window.location.href},
											success	: function(data) {
												if(data && data.alreadyLike){
													var span_utile = _like.find(".utile");
													span_utile.empty();
													$(span_utile).append("<span class='alreadyLike' title='Utile'>Utile</span>");
													$(span_utile).append("<span class='sep20'></span>Utile a " + data.numRivenditori + " rivenditore/i");
												}
											}
										});
									}
								)
								.appendTo(span_utile);
							}
							else{
								$(span_utile).append("<span class='alreadyLike' title='Utile'>Utile</span>");
							}

							$(span_utile).append("<span class='sep20'></span>Utile a " + data.numRivenditori + " rivenditore/i");
						}
		    		}
		    	});
				
			}
		);
	}
	
	
	//materiali di consumo
	if ($('.Materiali').size() != 0) {
		
	 $(".section input:checked").click();	
	 
	 $('div.checkbox').click(function(){
		
		var materialiCheck = $(this).parent();
		var boxMateriale = materialiCheck.parent();
		var nodeName = boxMateriale.prevAll(".datiAnagTestataMateriali").attr("id");
		nodeName = nodeName.replace("parent_","");
		var productName =  materialiCheck.prev(".boxMaterialeLab").text();
		var productValue =  materialiCheck.prev(".boxMaterialeLab").attr("id");
		productValue = productValue.replace("prodotto_","");
	 	
		if($(this).children("input").is(':checked')){
			
			materialiCheck.addClass('accendi');
			boxMateriale.addClass('accendiBox');
			$("#noSelMateriali").hide();
			$("#botConferma").show();
			$("#famiglia_"+nodeName).show();
			$("#prodottiSelezionati_"+nodeName).show();
			$("#materiale_"+productValue).remove();
			$("#prodottiSelezionati_"+nodeName).append("<div class='listaProd showList' id='materiale_"+productValue+"'>"+productName+"</div>");
			
		}else{		
			
			materialiCheck.removeClass('accendi');
	 		boxMateriale.removeClass('accendiBox');
	 		$("#materiale_"+productValue).remove();
			var checkeds = $("#boxParent_"+nodeName+" input:checked");
			if(checkeds.length<=0){
				$("#famiglia_"+nodeName).hide();
				$("#prodottiSelezionati_"+nodeName).hide();
			}
			var checkedsTot = $(".section input:checked");
			if(checkedsTot.length<=0){
				$("#noSelMateriali").show();
				$("#botConferma").hide();
			}	
			
		}
	 });
	}
});

function loadCategoriesBO(selectId, selectedValue){
	$.ajax({
		type	: "POST",
		url		: "/bob2b/partecipa/rest/getCategories.do",
		success	: function(data) {
			$.each(data, function(index, categoria){
				var selected = "";
				
				if(categoria.id == selectedValue){
					selected = "selected='selected'";
				}
				
				$("#" + selectId).append("<option value='" + categoria.id + "' " + selected + ">" + categoria.categoria + "</option>");
			});
			$("#" + selectId).skinner({'width':'230px','maxitem':'4', reload:true});
		}
	});
}

function showReceiverDiv(){
	
	var selection = $("#selezioneDestinatario").val();
	$("#sendAll").val('');
	$("#divutente").hide();
	$("#divgruppo").hide();
	if(selection != 'default'){
		if(selection == 'tutti'){
			$("#sendAll").val(true);
		}else{
			$("#div"+selection).show();
		}		
		
	}

 }

$('input[type=checkbox]').each(function(i,e){
	if($(e).hasClass('skinShowDiv')){
		wrapper = $('<div class="checkboxShowDiv"></div>').toggle(function(){
			$(this).addClass('active');
			$(this).children('input').attr('checked','checked');
			showDiv($(e).attr('id'));
		},function(){
			$(this).removeClass('active');
			$(this).children('input').removeAttr('checked');
			showDiv($(e).attr('id'));
		});
		$(e).wrap(wrapper);			
	}
});
$('input[type=checkbox]:checked').parent('.checkboxShowDiv').addClass('active');

$('.checkboxShowDiv').each(function(i,e){
	if($(e).parent('td').size()!=0){
		if($(e).next('label').outerHeight()>$(e).outerHeight()){
			$(e).next('label').height('auto');
		}
	}
});

function likeMessage(messId, value, flag){
	$.ajax({
		type	: "POST",
		url		: "/portaleb2b/area-personale/centro-messaggi/likeMessage.do",
		data	: {"value" : value, "id" : messId },
		success	: function(data) {
			if(data == 'like'){
			  if(flag == true){
					$("#likeStar_"+messId).html("<span class='star on' onclick='action_SC_Message_Center(function(){ likeMessage("+messId+",false,true); }, \"Delete_Bookmark\","+messId+",true); return false;' ></span>");
				}else{
					$("#likeStar").html("<span class='star on' onclick='action_SC_Message_Center(function(){ likeMessage("+messId+",false,false); }, \"Delete_Bookmark\","+messId+",true); return false;' ></span>");
				}
				  
			  }else{
				  if(flag == true){
					  $("#likeStar_"+messId).html("<span class='star' onclick='action_SC_Message_Center(function(){ likeMessage("+messId+",true,true); }, \"Bookmark\","+messId+",true); return false;' ></span>");
				  }else{
					  $("#likeStar").html("<span class='star' onclick='action_SC_Message_Center(function(){ likeMessage("+messId+",true,false); }, \"Bookmark\","+messId+",true); return false;' ></span>");
				  }

			  }
		}
	});
	
}

function showPasswordUserMonitoring(codiceFiscale){
	
	$.ajax({
		type	: "POST",
		url		: "/bob2b/business/usermonitoring/showPassword.do",
		data	: { "codiceFiscale" : codiceFiscale },
		success	: function(data) {
			if(data != ''){
				$("#box_"+codiceFiscale).parent().html(data+"<br><a href='#' id='box_" + codiceFiscale +"' onclick='hidePasswordUserMonitoring(\""+codiceFiscale+"\");return false; ' >nascondi</a>");
			  }
		}
	});
	
}

function hidePasswordUserMonitoring(codiceFiscale){
	
	$("#box_"+codiceFiscale).parent().html("<a href='#' id='box_" + codiceFiscale +"' onclick='showPasswordUserMonitoring(\""+codiceFiscale+"\");return false; ' >password</a>");
}


function addContractIdToForm(){
	
	var selection = $("#contractSelect").val();
	$('#contrattoSelezionato').val(selection);

}

function addTicketFirstStepSelect(){
	
	var selection = $("#ivr").val();
	if(selection == 'default'){
		$('#addTicketHiddenButton').hide();
	}else{
		$('#addTicketHiddenButton').show();
		$('#ivrSel').val(selection);
	}

}


function submitFormSelectionRegistration(formId, elementId, selectionId){
	
	var selection = $("#"+selectionId).val();	  	
	
		
		$("#"+elementId).val(selection);
    	$("#"+formId).submit();
		
	

 }
 
 function searchByTagOrCategory(){
	if($("#main > form[id='formSearchByTagOrCategory']").size() == 1){
		$("#formSearchByTagOrCategory > input[type='hidden']").remove();
	}
	else{
		$("<form id='formSearchByTagOrCategory' action='/searcher/portaleb2b/home.html' method='post'></form>")
		.appendTo($("#main"));
		$("#main");
	}
	
	for(var i = 0; i < arguments.length; i += 2){
		var _name 	= arguments[i];
		var _value 	= arguments[i + 1];
		
		if(_name == "directory"){
			_value = _value.split("/").join("\\/");
		}
		
		
		$("<input type='hidden' />").attr({
			name 	: _name,
			value 	: _value
		})
		.appendTo("#formSearchByTagOrCategory");
	}
	
	$("#formSearchByTagOrCategory").submit();
}

/* AML ADD Delegati  */
function revertFiscalCode(form) {
    if (form.fiscalCode.value.length == 16) {
    $.ajax({
         type    : "POST",
         url     : "/portaleb2b/area-personale/profilo/revertFiscalCode.do",
         data    : { "fiscalCode" : form.fiscalCode.value },
         success : function(data) {
             form.birthDateTime.value = data.birthDateTime;
             form.birthCity.value = data.birthCity;

             var sex = data.sex;
             if ($.trim(sex) != '') {
                sex = sex.toUpperCase();
                $('input[value="' + sex + '"]').attr('checked', 'checked');
            }
         }
    });
    }
}

function fiscalCodeFromSurname(form) {
    if (form.surname.value.length > 1) {
    $.ajax({
         type    : "POST",
         url     : "/portaleb2b/area-personale/profilo/fiscalCodeFromSurname.do",
         data    : { "surname" : form.surname.value },
         success : function(data) {
             if (form.fiscalCode.value.length == 0) {
                 form.fiscalCode.value += data.value;
             }
         }
    });
    }
}

function fiscalCodeFromName(form) {
    if (form.name.value.length > 1) {
    $.ajax({
         type    : "POST",
         url     : "/portaleb2b/area-personale/profilo/fiscalCodeFromName.do",
         data    : { "name" : form.name.value },
         success : function(data) {
             if (form.fiscalCode.value.length == 3) {
                 form.fiscalCode.value += data.value;
             }
         }
    });
    }
}

$.fn.animateRotate = function(startAngle, endAngle, duration, easing, complete){
    return this.each(function(){
        var elem = $(this);

        $({deg: startAngle}).animate({deg: endAngle}, {
            duration: duration,
            easing: easing,
            step: function(now){
                elem.css({
                  '-moz-transform':'rotate('+now+'deg)',
                  '-webkit-transform':'rotate('+now+'deg)',
                  '-o-transform':'rotate('+now+'deg)',
                  '-ms-transform':'rotate('+now+'deg)',
                  'transform':'rotate('+now+'deg)'
                });
            },
            complete: complete || $.noop
        });
    });
};
		
$(function(){
	if($.browser.msie && $.browser.version < 10){
	    $(".fa-spin").each(function(i,fa){
	        var infinite = function(){
	            $(fa).animateRotate(0, 360, 2000, "linear", infinite);
	        };
	        
	        infinite();
	    });
	}
});

$(function(){
	$(".section.deffered").each(
		function(index, section){
			loadSection(section);
		}
	);
	
	loadTextFromFile();
});

function loadSection(section){
	var jSection = $(section);

	if(!jSection.hasClass(".section.deffered")){
		jSection = jSection.closest(".section.deffered");
	}

	var url 		= jSection.data("url");
	var method 		= jSection.data("method");
	var title 		= jSection.data("title");
	var callback	= jSection.data("callback");
	
	var sectionHtml = '<div style="text-align: center;">';
	
	if(title){
		sectionHtml += '<span style="color: #61a521; font-weight: bold; font-size: 13px;">' + title +  '</span>';
		sectionHtml += '<div class="cl"></div>';
	}
	
	sectionHtml += 		'<span class="textError" style="display: none;">Errore in fase di caricamento.</span>';
	sectionHtml += 		'<div class="cl"></div>';
	sectionHtml += 		'<i class="fa fa-refresh fa-2x fa-spin" style="color: #61a521;"></i>';
	sectionHtml += '</div>';
	
	jSection.html(sectionHtml);
	
	$.ajax({
		cache 	: false,
		type	: method,
		url		: url,
		success	: function(data) {
			if(data != ''){
				jSection.html(data);
				
				if(callback){
					try{
						callback();
					}
					catch(e){
						console.warn(e);
					}
				}
		  	}
		},
		error: function(data){
			jSection.find(".textError").show();
			
			jSection.find("i")
			.removeClass("fa-spin")
			.hover(
				function(){
					$(this).addClass("fa-spin").css("cursor", "pointer");
				},
				function(){
					$(this).removeClass("fa-spin").css("cursor", "initial");
				}
			)
			.click(
				function(){
					loadSection(jSection);
				}
			);
		}
	});
};

function loadTextFromFile(content){
	/*
	 * example:
	 * <div class="textFromFile" data-filepath="/priv/messaggiInfo.xml" data-selector="messaggi[name='tooltipHomeMDC'] messaggio"></div>
	 */
	var elements = [];
	if(content){
		elements = $(content).find(".textFromFile");
	}
	else{
		elements = $(".textFromFile");
	}
	
	if($(elements).size() > 0){
		var files = [];
		
		$(elements).each(
			function(){
				var element 	= $(this);
				var selector 	= element.data("selector");
				var filepath 	= element.data("filepath");
				var hideIfEmpty	= element.data("hideIfEmpty");
				var file 		= files[filepath];
			
				if(!file){
					$.ajax({
						url		: filepath,
						async	: false,
						success	: function(data){
							files[filepath] = $(data);
							file = files[filepath];
						}
					});
				}
				
				var text = file.find(selector).text();
				
				if(text && text != ""){
					element.html(text);
				}
				else if(hideIfEmpty){
					element.closest(hideIfEmpty).hide();
				}
			}
		);
	}
}

$(function(){
	$.fn.dataTable.ext.errMode = function(settings, tn, msg){
		if(window.console){
			if(console.warn) {
				console.warn(msg);
			}
			else if(console.log){
				console.log(msg);
			}
		}
	}
	
	$(".dataTable-container").each(
		function(){
			applyDataTable($(this));
		}
	);
});

function applyDataTable(table){
	var tableContainer 			= $(table);
	var dom 					= tableContainer.data("dom") 					!= undefined ? eval(tableContainer.data("dom")) 					: "ftpB";
	var order 					= tableContainer.data("order") 					!= undefined ? eval(tableContainer.data("order")) 					: [];
	var columnDefs				= tableContainer.data("column-defs")  			!= undefined ? eval(tableContainer.data("column-defs")) 			: [];
	var pageLength				= tableContainer.data("page-length")  			!= undefined ? tableContainer.data("page-length") 					: 10;
	var lengthChange			= tableContainer.data("length-change") 			!= undefined ? tableContainer.data("length-change") 				: false;
	var info					= tableContainer.data("info") 					!= undefined ? tableContainer.data("info") 							: false;
	var filter					= tableContainer.data("filter") 				!= undefined ? tableContainer.data("filter") 						: true;
	var search					= tableContainer.data("search-text")  			!= undefined ? tableContainer.data("search-text") 					: "Filtra: ";
	var exportTable				= tableContainer.data("export")  				!= undefined ? tableContainer.data("export")						: false;
	var exportColumns			= tableContainer.data("export-columns") 		!= undefined ? eval(tableContainer.data("export-columns"))			: "";
	var exportColumnsExclusion	= tableContainer.data("export-columns-exclude") != undefined ? eval(tableContainer.data("export-columns-exclude"))	: [];
	var exportFileName			= tableContainer.data("export-filename") 		!= undefined ? tableContainer.data("export-filename")				: "*";
	
	var buttons = [];
	if(exportTable){
		
		// se settato, calcolo gli indici da includere nell'esportazione ('export-columns' viene ignorato)
		if(exportColumnsExclusion && exportColumnsExclusion.length > 0){
			var columnsIdx = [];
			tableContainer.find("table th").each(
				function(index){
					columnsIdx.push(index)
				}
			);
			
			exportColumns = $(columnsIdx).not(exportColumnsExclusion).get();
		}
		
		buttons = [
		    {
	            extend 			: "csv",
		        text 			: '<span class="export btn-green excel">SCARICA REPORT (Excel) </span>',
	        	fieldSeparator 	: ";",
	        	title 			: exportFileName,
		        exportOptions 	: {
		        	columns : exportColumns
		        }
		    }
		];
	}
	
	$("> table", tableContainer).DataTable({
		dom 		: dom,
		buttons 	: buttons,
		pageLength 	: pageLength,
		lengthChange: lengthChange,
		info 		: info,
		order 		: order,
		columnDefs 	: columnDefs,
		filter 		: filter,
		language 	: {
			search 		: search,
			zeroRecords : "Non ci sono risultati",
			paginate 	: {
				previous: "<",
				next 	: ">"
			}
		}
	});
}


$(function(){
	$('div#calendarAlert').each(function(i,e){
		nItem = $(e).size('div.item');
		timeClip = Number($('div#calendarAlert').attr('rel'))*1000;
		
		setInterval(function(){
			elem = $(e).children('div.active');
			if($(elem).next('div.item').size()>0){
				$(elem).fadeOut( "slow", function() {
					$(this).removeClass('active').next('div.item').addClass('active').fadeIn("slow");
				});
			}
			else{
				$(elem).fadeOut( "slow", function() {
					$(this).removeClass('active').parent(e).children('div.item:eq(0)').addClass('active').fadeIn("slow");
				});
			}
		},timeClip);
	});
});
		
$(function(){
	var videos = {
		"gev" : {
			type 		: "src",
			urls 		: {
				"webm": "https://isimply-cdn.itgate.com/OrdiniG&W.webm", 
				"ogv" : "https://isimply-cdn.itgate.com/OrdiniG&W.ogv", 
				"mp4" : "https://isimply-cdn.itgate.com/OrdiniG&W.mp4"
			},
			title 		: "",
			poster 		: "",
			width 		: 640,
			height 		: "",
			controls 	: true,
			autoplay 	: false,
			inline		: false
		},
		"wager-wise" : {
			type 		: "iframe",
			urls 		: "https://corsionline.tabaccai.it/wagerwise/",
			width 		: 700,
			height 		: 500,
			inline		: false
		}
	};
	
	var getVideoPlayer = function(videoPlayer){
		var classes 	= $(videoPlayer).attr("class");
		var category 	= classes.split(" ")[1];
		var video 		= videos[category]? videos[category] : [];
		video.mimetypes = video.type == "src"? (video.urls? video.urls : {}) : undefined;
		
		if($(videoPlayer).hasClass("external-params")){
			var getUrls = function(element){
				var dataUrls 	= $(element).data("urls");
				var urls 		= {};
				
				for(var index in dataUrls.split(",")){
					var splittedUrl = urls[index].split(":");
					urls[splittedUrl[0]] = splittedUrl[1];
				}
				
				return urls;
			};
			
			video.rel 		= $(videoPlayer).data("rel");
			video.type 		= $(videoPlayer).data("type")? $(videoPlayer).data("type") : "iframe";
			video.title 	= $(videoPlayer).data("title");
			video.poster 	= $(videoPlayer).data("poster");
			video.width 	= $(videoPlayer).data("width")? $(videoPlayer).data("width") : "500";
			video.height 	= $(videoPlayer).data("height");
			video.controls 	= $(videoPlayer).data("controls")? $(videoPlayer).data("controls") : true;
			video.autoplay 	= $(videoPlayer).data("autoplay")? $(videoPlayer).data("autoplay") : false;
			video.inline 	= $(videoPlayer).data("inline")? true : false;
			video.urls 		= video.type == "iframe"? $(videoPlayer).data("url") : getUrls(videoPlayer);
		}
		
		if(video.type == "src"){
			var videoplayer = '<video controls="' + video.controls + '" autoplay="' + video.autoplay + '" width="' + video.width + '" height="' + video.height + '" name="media">';
			
			for(var mimetype in video.mimetypes){
				videoplayer += '<source src="' + video.mimetypes[mimetype] + '" type="video/' + mimetype + '"></source>';
			}
			
			videoplayer += 'Il tuo browser non supporta il formato del video.';
			videoplayer += '</video>';
			
			if(video.inline){
				$(videoPlayer).html(videoplayer);
			}
			else{
				$("<div style='width: " + video.width + "px; height: " + video.height + "px;'></div>").showPopup();
				$("#contentPopupForm").html(videoplayer);
				
				$("#contentPopupForm video").bind("contextmenu", function(e) {
					e.preventDefault();
				});
			}
		}
		else if(video.type == "iframe"){
			videoplayer = '<iframe src="' + video.urls + '" width="' + video.width + '" height="' + video.height + '" style="border: none; overflow: hidden;" scrolling="no"></iframe>';

			if(video.inline){
				$(videoPlayer).html(videoplayer);
			}
			else{
				$(videoplayer).showPopup();
			}
		}
		else{
			console.error("must define a type")
			return;
		}
	};
	
	$(".videoplayer:not([data-inline])").click(function(){
		getVideoPlayer(this);
	});
	$(".videoplayer[data-inline]").each(function(){
		getVideoPlayer(this);
	});
});

$(function(){
	$("fieldset.accordion i.fa-chevron-circle-up, fieldset.accordion i.fa-chevron-circle-down").on('click', function(){
		if($(this).hasClass('fa-chevron-circle-up')){
			$(this).removeClass('fa-chevron-circle-up').addClass('fa-chevron-circle-down');
		}
		else{
			$(this).removeClass('fa-chevron-circle-down').addClass('fa-chevron-circle-up');
		}
		
		$('fieldset.accordion #description').slideToggle();
	});
});

var centerElement = function(element, container){
	$(element).position({
		my: 'center',
		at: 'center',
		of: (container || window),
		using: function (pos, ext) {
			$(this).animate({ top: (pos.top/2) }, 500);
		}
	});
};

// aggiunto il loader per le chiamate ajax
$(function(){
	$(document).ajaxSend(function(){
		if(arguments[2] && arguments[2].showLoader){
			var _loaderLayout = '<div id="ajaxLoaderMask" style="position: fixed; top: 0px; left: 0px; width: 100%; height: 100%; z-index: 9998; background-color: rgba(0,0,0,0.50);">';
			_loaderLayout += '<div style="text-align: center; margin: 250px auto; color: black; opacity: 3; background: white; width: 50px; height: 50px; line-height: 67px; border-radius: 100%;"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>';
			_loaderLayout += '</div>';
				
			$('body').append(_loaderLayout);
			
			centerElement('#ajaxLoaderMask div');
		}
	})
	.ajaxComplete(function() {
		$('#ajaxLoaderMask').remove();
	});
});

/* Restyle checkbox accettazioneTrattamentoDati in newbusiness */
function toggleAccettazioneTrattamentoDati(){
	var newValue, oldValue = $("#accettazioneTrattamentoDati").val();
	
    if(oldValue === "false")
		newValue = "true";
    else if(oldValue === "true")
		newValue = "false";
	
	$("#accettazioneTrattamentoDati").val(newValue);
	$(".accettazioneTrattamentoDati").toggleClass("active");
}

$(function(){
	$("#skeleton").each(
		function(index, section){
			loadSkeleton(section);
		}
	);
});

function loadSkeleton(section){
	var jSection = $(section);

	var url 		= jSection.data("url");
	var method 		= jSection.data("method");
	var title 		= jSection.data("title");
	var callback	= jSection.data("callback");

	$.ajax({
		cache 	: false,
		type	: method,
		url		: url,
		success	: function(data) {
			if(data != ''){
				jSection.removeClass("skeletonDeliveryWidget");
				jSection.html(data);

				if(callback){
					try{
						callback();
					}
					catch(e){
						console.warn(e);
					}
				}
		  	}
		}
	});
};


function printDiv(elem) {
            var contents = document.getElementById(elem).innerHTML;
            var frame1 = document.createElement('iframe');
            frame1.name = "frame1";
            frame1.style.position = "absolute";
            frame1.style.top = "-1000000px";
            document.body.appendChild(frame1);
            var frameDoc = (frame1.contentWindow) ? frame1.contentWindow : (frame1.contentDocument.document) ? frame1.contentDocument.document : frame1.contentDocument;
            frameDoc.document.open();
            frameDoc.document.write('<html><body>');
            frameDoc.document.write(contents);
            frameDoc.document.write('</body></html>');
            frameDoc.document.close();
            setTimeout(function () {
                window.frames["frame1"].focus();
                window.frames["frame1"].print();
                document.body.removeChild(frame1);
            }, 100);
            return false;
 };