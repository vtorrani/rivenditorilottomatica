$(function() {								
	applyDatePickerWithMaxRangeDays(720);	        
});

function caricaTipi(linea){
	jQuery('#codSalaDiv').hide();
	jQuery('#dataSingola').hide();
	jQuery('#dataRange').hide();	
	jQuery('.dataRange').hide();
	jQuery('#dataMese').hide();
	jQuery('#dataDal').val("");
	jQuery('#dataAl').val("");	
	jQuery('#dataDel').val("");
	
	idLinea = jQuery('#lineaBusiness').val();
	urlTo = '/portaleb2b/contabilita/getTipiDoc.do?random='+new Date().getTime();
	jQuery('#idTipoDocumento').empty();	
	jQuery('#idTipoDocumento').append(jQuery('<option></option>').val("").html("Seleziona"));
	jQuery.getJSON(urlTo,{idLinea : idLinea},function(listaTipi){
				for (i=0;i<listaTipi.length;i++){
					idDoc = listaTipi[i].id+'*'+listaTipi[i].platform+'*'+listaTipi[i].idDocType+'*'+listaTipi[i].idLineaBusiness;
					descrDoc = listaTipi[i].descrDocumento;						
					jQuery('#idTipoDocumento').append(jQuery('<option></option>').val(idDoc).html(descrDoc));									
				}												    		    	
//				jQuery('#idTipoDocumento').skinner({'reload':'true'});
				jQuery('#idTipoDocumento').skinner({'width':'90%', 'maxitem':'6', 'type':'left', 'reload':'true'});
			});
}
	
function caricaCal(){	
	urlTo = '/portaleb2b/contabilita/getDocById.do?random='+new Date().getTime();
	jQuery('#date').val("");	
	jQuery.getJSON(urlTo,{idLinea : jQuery('#lineaBusiness').val(),idDoc : jQuery('#idTipoDocumento').val()},function(docum){		
		if (docum.codSalaRequired!=null && docum.codSalaRequired)
			jQuery('#codSalaDiv').show();
		else
			jQuery('#codSalaDiv').hide();
		if (docum.periodicita.annuale!= null && docum.periodicita.annuale.value){
			jQuery('#dataSingola').hide();
			jQuery('#dataRange').hide();
			jQuery('.dataRange').hide();
			jQuery('#dataMese').show();	
			writeYearOptions(docum.periodicita.annuale.lastYears);	
			jQuery("#monthList").skinner({'reload':'true'});	
		} else if (docum.periodicita.mensile!=null && docum.periodicita.mensile.value){
			jQuery('#dataSingola').hide();
			jQuery('#dataRange').hide();
			jQuery('.dataRange').hide();
			jQuery('#dataMese').show();
			if (docum.periodicita.mensile.period == 'quarter')
				writeMonthOptions(null,true);
			else
				writeMonthOptions(docum.periodicita.mensile.lastMonth,false);	
			jQuery("#monthList").skinner({'reload':'true'});	
		} else if (docum.periodicita.singleDate!=null && docum.periodicita.singleDate.value){
			jQuery('#dataSingola').show();
			jQuery('#dataDel').val('');
			if (docum.periodicita.singleDate.daysOfWeek != null)
				applyDatePicker(null,docum.periodicita.singleDate.daysOfWeek);
			else if (docum.periodicita.singleDate.dayOfMonth != null)
				applyDatePicker(docum.periodicita.singleDate.dayOfMonth);
			else if (docum.periodicita.singleDate.defaultDate != null)
				applyDatePicker(null,null,docum.periodicita.singleDate.defaultDate,docum.periodicita.singleDate.blockPastSearch);
			else
				applyDatePicker();
			jQuery('#dataRange').hide();
			jQuery('.dataRange').hide();
			jQuery('#dataMese').hide();	
		} else if (docum.periodicita.dataRange!=null && docum.periodicita.dataRange){
			//alert(docum.periodicita.dataRange.maxRange);
			applyDatePickerWithMaxRangeDays(docum.periodicita.dataRange.maxRange);
			jQuery('#dataSingola').hide();
			jQuery('#dataRange').show();	
			jQuery('.dataRange').show();
			jQuery('#dataMese').hide();		
		} else {
			jQuery('#dataSingola').hide();
			jQuery('#dataRange').hide();	
			jQuery('.dataRange').hide();
			jQuery('#dataMese').hide();
		}	
		jQuery('#xslName').val(docum.xsl);					    		    	
	});
}

function cerca(){
	jQuery('#loading').show();
	jQuery('#iddoc').val('');
	
	var dateSC;
	
	if(jQuery('#dataRange').is(":visible")){
		dateSC = jQuery('#dataDal').val()+" - "+jQuery('#dataAl').val();
	}else if(jQuery('#dataSingola').is(":visible")){
		dateSC = jQuery('#dataDel').val();
	}else if(jQuery('#dataMese').is(":visible")){
		dateSC = jQuery('#monthList option:selected').html();
	}else {
		dateSC = "";
	}
	
	var serviceSC = jQuery('#lineaBusiness option:selected').html();
	var typeDocSC = jQuery('#idTipoDocumento option:selected').html();
	
	idDocSel = jQuery('#idTipoDocumento').val();
	platform = idDocSel.split('\*')[1];
	idDocType = idDocSel.split('\*')[2];
	idLineaDoc = idDocSel.split('\*')[3];
	jQuery('#platform').val(platform);
	jQuery('#idDocType').val(idDocType);
	jQuery('#idLineaDoc').val(idLineaDoc);
	
	formSerial = jQuery('#contabilitaForm').serialize();
	urlTo = 'ricercaDocumento.do?random='+new Date().getTime();
	jQuery.post(urlTo,formSerial,function(res){
		jQuery('#loading').hide();
		jQuery('.results').html(res);
			action_SC_Bookkeeper_Research(serviceSC,typeDocSC,dateSC,resultSize);
		});				
	/*if(typeof(resultSize) != 'undefined' && resultSize != null){
		action_SC_Bookkeeper_Research(serviceSC,typeDocSC,dateSC,resultSize);
		//alert(resultSize);
	}	*/
}

function getLastMonths(n) {
    monthNames = ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
		months = new Array();    
    today = new Date();    
    year = today.getFullYear();
    month = today.getMonth()+1;        
    i = 0;
    do {
        months.push('01/'+(month > 9 ? "" : "0")+month +"/"+ year+"*"+monthNames[month-1]+" "+ year);
        if(month == 1) {
            month = 12;
            year--;
        } else {
            month--;
        }
        i++;
    } while(i <= n);
    months.shift();
    return months;    
}

function getTrimestrali() {
    monthNames = ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
    months = new Array();
    
    today = new Date();    
    year = today.getFullYear();
    month = today.getMonth()+1;    
    
    var i = 0;
    do {
        if (month==3 || month==6 || month==9 ||month==12){
             months.push('01/'+(month > 9 ? "" : "0")+month +"/"+ year+"*"+monthNames[month-1]+" "+ year);
        }       
        if(month == 1) {
            month = 12;
            year--;
        } else {
            month--;
        }
        i++;
    } while(i <12);
    return months;    
}

function getLastYears(n) {
    years = new Array();    
    today = new Date();    
    year = today.getFullYear();     
    year--;
    i = 0;
    do {
        years.push('01/12/'+ year+"*"+year);
        year--;        
        i++;
    } while(i < n);    
    return years;    
}

function writeMonthOptions(n,trimestrali) { 
	 if (trimestrali)
		 optionValues = getTrimestrali();
	 else
   	 optionValues = getLastMonths(n);
   $("#monthList").empty();
   $('#monthList').append($('<option></option>').val("").html("Seleziona"));
   for(i=0; i<optionValues.length; i++) {
       arrVal = optionValues[i].split("*");
       $('#monthList').append($('<option></option>').val(arrVal[0]).html(arrVal[1]));
    }    
}

function writeYearOptions(n) {       
   optionValues = getLastYears(n);
   $("#monthList").empty();
   $('#monthList').append($('<option></option>').val("").html("Seleziona"));
   for(i=0; i<optionValues.length; i++) {
       arrVal = optionValues[i].split("*");      
       $('#monthList').append($('<option></option>').val(arrVal[0]).html(arrVal[1]));
    }    
}

function updateDateFromDel(){	
	$('#date').val($('#dataDel').val());			
}

function updateDateFromMese(){				
		$('#date').val($('#monthList').val());	
}

function applyDatePicker(dayOfMonth,daysOfWeek,defaultDate,blockPast){
	$('#dataDel').datepicker('destroy');
	$('#dataDel').datepicker({						
		dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ],
		minDate: blockPast ? 0 : null,
		maxDate: 0,
		beforeShowDay: function(date) {	   
						if (dayOfMonth){
							if (date.getDate() == dayOfMonth)
								return [true, ''];
							else
								return [false,'ui-state-inactive'];
						} else if (daysOfWeek!=null){
							//gestione vecchia contabilita,separate da ; in singleDate
							daysEnabled = null;
							arrSettCont = daysOfWeek.split(';');	 
							if (arrSettCont.length>1){
								dataSwitch = new Date(2014,9,5);
								if (date<dataSwitch)
									daysEnabled = arrSettCont[1];
								else
									daysEnabled = arrSettCont[0];
							} else 
								daysEnabled = arrSettCont[0];
							days = daysEnabled.split(',');											             		
				if (containsDay(days,''+date.getDay())) 
					return [true, ''];
				else
					return [false,'ui-state-inactive'];
			} else 	             			             
				return [true, ''];           
		}
	});			
	
	if(defaultDate){
		if(defaultDate == "today")
			defaultDate = new Date();
		$('#dataDel').datepicker("setDate", defaultDate);
		updateDateFromDel();
	}	
}

function applyDatePickerWithMaxRangeDays(maxdays){
	$("#dataDal").datepicker("destroy");
	$("#dataAl").datepicker("destroy");
	$("#dataDal").datepicker({
		minDate: '-2y',
		maxDate: new Date(),
		dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ],
		onClose: function( selectedDate ) {
		    $("#dataAl").datepicker( "option", "minDate", selectedDate );
		    
		    var maxDate = $("#dataDal").datepicker('getDate');            
            maxDate.setDate(maxDate.getDate() + maxdays);
            
		    $("#dataAl").datepicker( "option", "maxDate", maxDate );
		    if($("#dataAl").val() == "" )
		    	$("#dataAl").datepicker( "setDate", selectedDate );
			}
	});
	
	$("#dataAl").datepicker({
		maxDate: new Date(),
		dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ],
		onClose: function( selectedDate ) {
		    $("#dataDal").datepicker( "option", "maxDate", selectedDate );
		    
		    var minDate = $("#dataAl").datepicker('getDate');            
		    minDate.setDate(minDate.getDate() - maxdays);
		    $("#dataDal").datepicker( "option", "minDate", minDate );
		}
	});
	$("#monthList").skinner({'type':'left','width':'90%','maxitem':'4'});
	$("#dataDal").datepicker("refresh");
	$("#dataAl").datepicker("refresh");
}

function containsDay(a, arr) {
    var i = a.length;
    while (i--) {
       if (a[i] == arr) {
           return true;
       }
    }
    return false;
}

function clearDates(e){
	e.preventDefault();
	$("#dataDal").datepicker('setDate', null);
	$("#dataAl").datepicker('setDate', null);
	$("#dataAl").datepicker( "option", "minDate", null );
	$("#dataDal").datepicker( "option", "minDate", null );
	$("#dataDal").datepicker( "option", "maxDate", null );
	$("#dataAl").datepicker( "option", "maxDate", null );
	//$("#dataDal").val('');
	//$("#dataAl").val('');
}

