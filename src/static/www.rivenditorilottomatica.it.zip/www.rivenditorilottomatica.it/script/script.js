/* 
 * Author: Andrea Bianchin
 * 09/2012
*/



var l8 = {
	init : function(){	
		
		if($('.slider-giochi').size()!=0){
			l8.sliderGiochi();
		}
		if($('.slider-concorsi').size()!=0){
			l8.sliderConcorsi();
		}
		if($('div.slider-concorsi-full').size()!=0){
			l8.sliderConcorsiFull();
		}
		if($('div.bannerHPPriv').size()!=0){
			l8.sliderBannerHPPriv();
		}
		
		/* style imamgini contribuite */
		$('img[align="left"]').addClass('imgLeft');
		$('img[align="right"]').addClass('imgRight');

		/* attivatore del visual in hp */
		$('#visual').sliderVisual();

		/* attivatore del visual in hp */
		/*
		$('#locandinaVisual').sliderLocandina();

		if($('div#contLocandine').size() != 0){
			$("div.locandina").click(
				function () {
					$("ul.listaLocandine").empty();
					$("div.listaLocandine").children().clone().css("display", "none").appendTo("ul.listaLocandine");
					var li = $("ul.listaLocandine").find("li[id=" + $(this).attr("id") + "]");
					li.addClass("active").removeAttr("style");
					showPopup("locandinePopup");
				}
			);
		}
		*/
		
		/* bottoni tabellati */
		if($('div.btns-tabled').size()!=0){
			$('div.btns-tabled').each(function(){
				nBtn = $(this).find('.btn').size();
				thisWidth = $(this).width();
				myWidth = Math.floor(thisWidth/nBtn);
				$(this).children('.btn').width(myWidth);
				$(this).children('.btn:last').children('a').css('margin-right','0px');
			});
		}
	
		/* skin delle select */
		$('select:not(.filter)').skinner({'width':'210px'	, 'maxitem':'4'});
		$('select.assistenza')	.skinner({'width':'230px'	, 'maxitem':'4'});
		$('select.author')		.skinner({'width':'25%'		, 'maxitem':'4', 'type':'left'});
		$('select.date')		.skinner({'width':'14%'		, 'maxitem':'4', 'type':'left'});
		$('select.stati')		.skinner({'width':'10%'		, 'maxitem':'4', 'type':'left'});
		$('select.aree')		.skinner({'width':'10%'		, 'maxitem':'4', 'type':'left'});
		$('select.servizio')	.skinner({'width':'265px'	, 'maxitem':'4', 'type':'left'});
		$('select.game')		.skinner({'width':'90%'		, 'maxitem':'4', 'type':'left', 'textwrap':true});
		$('select.docs')		.skinner({'width':'90%'		, 'maxitem':'4', 'type':'left'});
		$('select.istruzione')	.skinner({'width':'40%'		, 'maxitem':'4', 'type':'left'});
		$('select.dataGiorno')	.skinner({'width':'10%'		, 'maxitem':'4', 'type':'left'});
		$('select.dataMese')	.skinner({'width':'24%'		, 'maxitem':'4', 'type':'left'});
		$('select.dataAnno')	.skinner({'width':'20%'		, 'maxitem':'4', 'type':'left'});
		$('select.terminali')	.skinner({'width':'90%'		, 'maxitem':'4', 'type':'left'});
		$('select.sala')		.skinner({'width':'400px'		, 'maxitem':'4', 'type':'left'});
		
		$('ul.news-list li').each(function(i,e){
			$(e).click(function(){
				$('ul.news-list li').removeClass('active');
				$(this).addClass('active');
				$('ul.news-viewer li').removeClass('active');
				$('ul.news-viewer li:eq('+i+')').addClass('active');
			});
		});

		$('.toggle').click(function(){
			var toggle 		= $(this);
			var itemsText 	= toggle.parent().find('.text');
			
			itemsText.each(
				function(index, item){
					var itemText = $(item);
					
					if(itemText.hasClass('active')){
						itemText.slideUp(500,function(){
							itemText.removeClass('active');
						})
						toggle.removeClass('open');
					}
					else{
						itemText.slideDown(500,function(){
							itemText.addClass('active');
						});
						toggle.addClass('open');
					}
				}
			);
		});
		
		$('input[type=radio]').each(function(i,e){
			if($(e).hasClass('skin')){
				wrapper = $('<div class="radio" rel="'+$(e).attr('name')+'"></div>').click(function(){				
						name = $(e).attr('name');
						$('input[name='+name+']').each(function(j,f){
							$(f).removeAttr('checked');
							$(f).parent('.radio').removeClass('active');
						});
						$(this).addClass('active');			
						$(this).children('input').attr('checked','checked');				
				});
				$(e).wrap(wrapper);
			}			
		});

		$('input[type=radio]:checked').parent('.radio').addClass('active');
		
		$('input[type=checkbox]').each(function(i,e){
			if($(e).hasClass('skin')){
				wrapper = $('<div class="checkbox"></div>').toggle(function(){
					$(this).addClass('active');
					$(this).children('input').attr('checked','checked');
					if($(e).hasClass('showDiv')){
						showDiv($(e).attr('id'));
					}
				},function(){
					$(this).removeClass('active');
					$(this).children('input').removeAttr('checked');
					if($(e).hasClass('showDiv')){
						showDiv($(e).attr('id'));
					}
				});
				$(e).wrap(wrapper);			
			}
		});
		$('input[type=checkbox]:checked').parent('.checkbox').addClass('active');
		
		$('.checkbox').each(function(i,e){
			if($(e).parent('td').size()!=0){
				if($(e).next('label').outerHeight()>$(e).outerHeight()){
					$(e).next('label').height('auto')
				}
			}
		});
		
		$('label').each(function(j,f){
			if($(f).prev('.checkbox').size()!=0){
				$(f).click(function(){
					$(this).prev('.checkbox').click();
				})
			}
			if($(f).prev('.radio').size()!=0){
				$(f).click(function(){
					$(this).prev('.radio').click();
				})
			}
			if($(f).prev('.radio-green').size()!=0){
				$(f).click(function(){
					$(this).prev('.radio-green').click();
				})
			}
		});

		if($('div.clip').size()!=0){
			$('div.clip').each(function(i,e){
				nItem = $(e).size('div.item');
				timeClip = Number($('div.clip').attr('rel'))*1000;
				setInterval(function(){
					elem = $(e).children('div.active');
					if($(elem).next('div.item').size()>0){
						$(elem).removeClass('active').next('div.item').addClass('active');
					}else{
						$(elem).removeClass('active').parent(e).children('div.item:eq(0)').addClass('active');
					}
				},timeClip);
			});
		}

		if($('div.alert.active').size()!=0){
			$('div.alert.active').each(function(i,e){
				nItem = $(e).size('p');
				timeClip = Number($('div.alert.active').attr('rel'))*1000;
				setInterval(function(){
					elem = $(e).children('p.active');
					if($(elem).next('p').size()>0){
						$(elem).removeClass('active').next('p').addClass('active');
					}else{
						$(elem).removeClass('active').parent(e).children('p:eq(0)').addClass('active');
					}
				},timeClip);
			});
		}
		
		if($('div.timeBanner').size()!=0){
			$('div.timeBanner').each(function(i,e){
				nItem = $(e).size('a.banner');
				timeClip = Number($('div.timeBanner').attr('rel'))*1000;
				setInterval(function(){
					elem = $(e).children('a.active');
					if($(elem).next('a').size()>0){
						$(elem).removeClass('active').next('a').addClass('active');
					}else{
						$(elem).removeClass('active').parent(e).children('a:eq(0)').addClass('active');
					}
				},timeClip);
			});
		}
		
		/* tooltips */
		$('span.info').qtip({ content: { text: function() { return $(this).find('p').html(); } } });
		$('a.addDocs').qtip({ 
			content: { 
				text: function() { 
					return $(this).find('span:eq(0)').find('p').html(); 
				} 
			},
			position : { my : 'bottom center', at : 'top center' },
			style : {classes : 'tooltip-green'}
		});
		
		$('input.tooltip-right').qtip({
			content : { text : function(api) { return $(this).attr('rel'); } },
			position : { my : 'left center', at : 'right center' },
			style : {classes : 'ui-tooltip-rounded-custom'},
			show : { event : 'focus mouseover'},
			hide : { event : 'blur mouseout'}
		}); 	
		$('input.tooltip-left').qtip({
			content : { text : function(api) { return $(this).attr('rel'); } },
			position : { my : 'right center', at : 'left center' },
			style : {classes : 'ui-tooltip-rounded-custom'},
			show : { event : 'focus mouseover'},
			hide : { event : 'blur mouseout'}
		}); 	
		$('div.infoOrange').qtip({
			content : { text : function(api) { return $(this).attr('rel'); } },
			position : { my : 'right center', at : 'left center' },
			style : {classes : 'ui-tooltip-rounded-custom'},
			show : { event : 'focus mouseover'},
			hide : { event : 'blur mouseout'}
		});
		
		
		/* setto altezze colonna e contenuto*/
		if($('.sidebar:eq(0)').height()>$('.mainCc:eq(0)').outerHeight()){
			$('.mainCc:eq(0)').css('min-height', $('.sidebar:eq(0)').height());
		}
		
		$('nav > ul > li').each(function(i,e){
			$(e).hover(function(){
				$('#menu-focus').show();
				myLeft = Math.round($(this).position().left+(($(e).width()/2)-($('#menu-focus').width()/2)));	
				$('#menu-focus').css({'left':myLeft+'px'})
			})
		});
		
		$('nav').hover(function(){},function(){	
			if($('nav > ul > li.active:visible').size()!=0){
				$('#menu-focus').show();
				myLeft = Math.round($('nav > ul > li.active').position().left+(($('nav > ul > li.active').width()/2)-($('#menu-focus').width()/2)));
				$('#menu-focus').css({'left':myLeft+'px'});	
			}else{
			  $('#menu-focus').hide();
			}
			  
		});
		
		$('.secondLiv').each(function(i,e){		
			if($(e).hasClass('double')){
				$(e).find('ul').last().css('margin-left','3.9%');
			}
			$(e).find('ul').each(function(){
				$(this).find('li').last().css('border-bottom','none');
			})		
		});
		
		$('.cols li:last-child').css('background','none');
		$('.boxCentral .item:last').css('border','none');
		
		/* posiziono il menu-focus */
 		setTimeout(function(){
			if($('#menu-focus').size()!=0 && $('nav > ul > li.active:visible').length>0){
				$('#menu-focus').show();
				myLeftStart = Math.round($('nav > ul > li.active').position().left+(($('nav > ul > li.active').width()/2)-($('#menu-focus').width()/2)));			
				$('#menu-focus').css({'left':myLeftStart+'px'});
			}else{
			  $('#menu-focus').hide();
			}
		},500);
		
		/* controllo direzione dropdown */
		$('nav > ul > li').hover(function(){
			elem = $(this);
			setTimeout(function(){
				if(elem.find('.secondLiv:eq(0)').size()!=0){
					pageWidth = $("nav:eq(0)").width();
					parentLeft = elem.position().left;
					secondLiv = elem.find('.secondLiv:eq(0)');
					elementWidth = secondLiv.width();
					elementLeft = secondLiv.position().left;
					if((pageWidth-(elementWidth+elementLeft+parentLeft))<0) {
						secondLiv.css({'left':'auto','right':'0px'});
					}
				}
			},150);		
		});
		
		/* setto lingua calendario */
		$.datepicker.setDefaults({
			   showOn: 'both',
			   buttonImageOnly: true,
			   buttonImage: "/css/i/ico-calendar.gif",
			   showOtherMonths: true,
			   selectOtherMonths: true
	    });
		$.datepicker.setDefaults($.datepicker.regional['it']);
		$( "#data-dal" ).datepicker({dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ]});
		$( "#data-al" ).datepicker({dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ]});
			
		/* calendario */
		$('.datepicker').each(function(i,e){
			$(e).datepicker({
				dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ]
			});	
		});		

		/* calendario multiplo */
		$('.datepicker3').each(function(i,e){
			$(e).datepicker({
				numberOfMonths: 3,
				dayNamesMin: [ "D", "L", "M", "M", "G", "V", "S" ]
			});	
		});
		
	    /* nascondo il popup se l'utente clicca l'overlay layer, dialogbox o btn */
	    $('a.button, #dialog-overlay, a.btn-annulla').click(function () {     
	        $('#dialog-overlay, #dialog-box').hide();       
	        return false;
	    });
	    
		// pagina doc personali
		$('ul#docPers a.heading').click(function() {
			if($(this).parent().hasClass('current')) {
				$(this).siblings('ul').slideUp('slow',function() {
					$(this).parent().removeClass('current');
				});
			} else {
				$('ul#docPers li.current ul').slideUp('slow',function() {
					$(this).parent().removeClass('current');
				});
				$(this).siblings('ul').slideToggle('slow',function() {
					$(this).parent().toggleClass('current');
				});
			}
			return false;
		});
		//pulsante upload customizzato pag cambia foto
		if($('#flUpload').size() != 0) {
			$(function(){
				$('#flUpload').customFileInput();
			});
		} 
		
	    /* per la pagina assistenza */
	   
	   
	   if($('.accHiddenPanel').size() != 0) {$('.accHiddenPanel').hide();}
	    
	    if($('.expandFaq').size() != 0) {
	    	$('.expandFaq').each(function (i, e) {
	    		var scostL = $(this).width();
	    		var le = $('a.showHiddenAccItem').width();
	    		$('a.showHiddenAccItem').eq(i).css("left",(scostL - le)/2);    		
	    	});
	    }
	    
	    if ($('.accItem').size() != 0) {
            $('.accItem a.showHiddenAccItem').each(function (i, e) {
                $(e).click(function (event) {
                    event.stopPropagation();
                    $(e).toggleClass('open');
                    if($('.accHiddenPanel').eq(i).is(':visible')){
                    	$('.accHiddenPanel').eq(i).slideUp(500,"easeCool");
                    }else{
                    	$('.accHiddenPanel').eq(i).slideDown(500,"easeCool");

                    }
                });
            });
        }
	},

	sliderGiochi : function(){

		$('.slider-giochi .item').each(function(i,e){
			$(e).find('.first:eq(0)').click(function(){
				$(this).parent('.item').animate({'top':'-220px'}, 500, 'easeCool');
				var gameO = $(this).parent('.item').find('.text-gioco h4').html();
				action_SC_Open_Slide(gameO);
			})
			$(e).find('.back').click(function(){
				$(this).parent('.second').parent('.item').animate({'top':'0'}, 500, 'easeCool');
				var gameC = $(this).parent('.item').find('.text-gioco h4').html();
                action_SC_Close_Slide(gameC);

			})
		});

		var stopped = true;
		var nItem = $('.slider-giochi .item:visible').size();
		var wItem = $('.slider-giochi .item').outerWidth();
		var rPadding = 1;
		
		$('.slider-giochi div.train').css({'width':nItem*(wItem+rPadding)+'px'})

		$('.slider-giochi .prev:eq(0)').click(function(){
			if(stopped == true){
				var trainLeft = $('.slider-giochi div.train:eq(0)').css('left');
				var endTrain = $('.slider-giochi div.train:eq(0)').width()-$('.slider-giochi .cont:eq(0)').width();
				if(trainLeft!='auto' && trainLeft!='0px'){
					stopped = false;
					$('.slider-giochi div.train:eq(0)').animate({ 'left': '+=' + wItem}, 500, 'easeCool', function () {stopped = true;});
				}
				else{
					stopped = false;
					$('.slider-giochi div.train:eq(0)').animate({ 'left':-endTrain}, 500, 'easeCool', function () {stopped = true;});
				}
			}
		});
		
		$('.slider-giochi .next:eq(0)').click(function(){
			if(stopped == true){
				var trainLeft = $('.slider-giochi div.train:eq(0)').css('left');
				var contWidth = $('.slider-giochi .cont:eq(0)').width();
				var extraW = $('.slider-giochi div.train:eq(0)').width()-contWidth;
				trainLeft = (trainLeft=='auto') ? '0px' : trainLeft;
				if(extraW+Number(trainLeft.split('px')[0])>=wItem){
					stopped = false;
					$('.slider-giochi div.train:eq(0)').animate({ 'left': '-=' + wItem}, 500, 'easeCool', function () {stopped = true;});
				}else{
					stopped = false;
					$('.slider-giochi div.train:eq(0)').animate({ 'left': '0px'}, 500, 'easeCool', function () {stopped = true;});
				}
			}
		});

		/* action input filter*/
		$('input.green').each(function(i,e){
			if($(e).attr('checked')=='checked'){
				addClass =' active';
			}else{
				addClass = '';
			}
			wrapper = $('<div class="radio-green'+addClass+'" rel="'+$(e).attr('name')+'"></div>').click(function(){				
				name = $(e).attr('name');
				$('input[name='+name+']').each(function(j,f){
					$(f).removeAttr('checked')
					$(f).parent('.radio-green').removeClass('active');
				});
				$(this).addClass('active');			
				$(this).children('input').attr('checked','checked');
				
				if($(this).children('input').val()=='all'){
					//$('.slider-giochi div.train:eq(0)').fadeOut(100).fadeIn(100);
					$('.slider-giochi .item').show();
					$('.slider-giochi div.train:eq(0)').animate({ 'left': '0px'}, 500, 'easeCool');
					nItemTot = $('.slider-giochi .item:visible').size();
					$('.slider-giochi div.train:eq(0)').css({'width':nItemTot*(wItem+rPadding)+'px'})
					
					//alert($('.slider-giochi .item:visible').size())
				}else{
					//$('.slider-giochi div.train:eq(0)').fadeOut(100).fadeIn(100);
					$('.slider-giochi .disabled').hide();
					$('.slider-giochi div.train:eq(0)').animate({ 'left': '0px'}, 500, 'easeCool');
					nItemTot = $('.slider-giochi .item:visible').size();
					$('.slider-giochi div.train:eq(0)').css({'width':nItemTot*(wItem+rPadding)+'px'});
					
					//alert($('.slider-giochi .item:visible').size())
				}
			});
			$(e).wrap(wrapper);
		});

	},

	sliderConcorsi : function(){

		$('.slider-concorsi').each(function(i,e){
			$(e).find('.next').click(function(){
				activeItem = $(this).parent('.slider-concorsi').find('.active:eq(0)');
				activeItem.removeClass('active');
				if(activeItem.next('.item').size()>0){
					activeItem.next('.item').addClass('active');
				}else{
					$(this).parent('.slider-concorsi').find('.item:eq(0)').addClass('active');
				}
			})
			$(e).find('.prev').click(function(){
				activeItem = $(this).parent('.slider-concorsi').find('.active:eq(0)');
				activeItem.removeClass('active');
				if(activeItem.prev('.item').size()>0){
					activeItem.prev('.item').addClass('active');
				}else{
					$(this).parent('.slider-concorsi').find('.item:last').addClass('active');
				}
			})
		});
	},
	sliderConcorsiFull : function(){
		stopped = true;
		nItem = $('div.slider-concorsi-full div.item:visible').size();
		wItem = $('div.slider-concorsi-full div.item').outerWidth();
		$('div.slider-concorsi-full div.train').css({'width':nItem*wItem+'px'})
		
		$('div.slider-concorsi-full').each(function(i,e){

			if(nItem<7){
				$(e).find('div.next').hide();
				$(e).find('div.prev').hide();
			}else{
				$(e).find('div.next').show();
				$(e).find('div.prev').show();
			}


			$(e).find('.next').click(function(){
				if(stopped==true){
					trainLeft = $('div.slider-concorsi-full div.train:eq(0)').css('left');
					contWidth = $('div.slider-concorsi-full .cont:eq(0)').width();
					extraW = $('div.slider-concorsi-full div.train:eq(0)').width()-contWidth;
					trainLeft = (trainLeft=='auto') ? '0px' : trainLeft;
					if(extraW+Number(trainLeft.split('px')[0])>=wItem){
						stopped = false;
						$('div.slider-concorsi-full div.train:eq(0)').animate({ 'left': '-=' + wItem}, 500, 'easeCool', function () {stopped = true;});
					}else{
						stopped = false;
						$('div.slider-concorsi-full div.train:eq(0)').animate({ 'left': '0px'}, 500, 'easeCool', function () {stopped = true;});
					}
				}
			})
			$(e).find('.prev').click(function(){
				if(stopped==true){
					trainLeft = $('div.slider-concorsi-full div.train:eq(0)').css('left');
					endTrain = $('div.slider-concorsi-full div.train:eq(0)').width()-$('div.slider-concorsi-full .cont:eq(0)').width();
					if(trainLeft!='auto' && trainLeft!='0px'){
						stopped = false;
						$('div.slider-concorsi-full div.train:eq(0)').animate({ 'left': '+=' + wItem}, 500, 'easeCool', function () {stopped = true;});
					}else{
						stopped = false;
						$('div.slider-concorsi-full div.train:eq(0)').animate({ 'left':-endTrain}, 500, 'easeCool', function () {stopped = true;});
					}
				}
			})
		});
	},

	sliderBannerHPPriv : function(){
		timeClip 	= Number($('div.bannerHPPriv').attr("rel")) * 1000;
		wItem 		= $('div.bannerHPPriv .banner').outerWidth();
		nItem 		= $('div.bannerHPPriv .banner').size();
		
		$('div.bannerHPPriv div.train').css({'width': nItem * wItem + 'px'});
		
		var sliderFunction = function(){
			stopped = true;
			
			if(stopped == true){
				trainLeft 	= $('div.bannerHPPriv div.train:eq(0)').css('left');
				contWidth 	= $('div.bannerHPPriv .cont:eq(0)').width();
				extraW 		= $('div.bannerHPPriv div.train:eq(0)').width() - contWidth;
				trainLeft 	= (trainLeft == 'auto') ? '0px' : trainLeft;
				widthItem	= $('div.bannerHPPriv .banner').outerWidth();
				
				if(extraW + Number(trainLeft.split('px')[0]) >= widthItem){
					stopped = false;
					$('div.bannerHPPriv div.train:eq(0)').animate({ 'left': '-=' + contWidth}, 500, 'easeCool', function () {stopped = true;});
				}
				else{
					stopped = false;
					$('div.bannerHPPriv div.train:eq(0)').animate({ 'left': '0px'}, 500, 'easeCool', function () {stopped = true;});
				}
			}
		};
		
		var sliderInterval = setInterval(sliderFunction, timeClip);
		
		$('div.bannerHPPriv .banner').hover(function(){
			clearInterval(sliderInterval);
		}, function(){
			sliderInterval = setInterval(sliderFunction, timeClip);
		});
		
		if($('div.bannerHPPriv').data('arrow') == true){
			$('div.bannerHPPriv .cont').append('<span class="left_arrow fa fa-chevron-left"></span>');
			$('div.bannerHPPriv .cont').append('<span class="right_arrow fa fa-chevron-right"></span>');
			
			$('div.bannerHPPriv .left_arrow').click(function(){
				trainLeft 	= $('div.bannerHPPriv div.train:eq(0)').css('left');
				contWidth 	= $('div.bannerHPPriv .cont:eq(0)').width();
				extraW 		= $('div.bannerHPPriv div.train:eq(0)').width() - contWidth;
				trainLeft 	= (trainLeft == 'auto') ? '0px' : trainLeft;
				widthItem	= $('div.bannerHPPriv .banner').outerWidth();
				
				stopped = false;
				if(Number(trainLeft.split('px')[0]) < 0){
					$('div.bannerHPPriv div.train:eq(0)').animate({ 'left': '+=' + contWidth}, 500, 'easeCool', function () {stopped = true;});
				}
				else{
					$('div.bannerHPPriv div.train:eq(0)').animate({ 'left': '-=' + extraW}, 500, 'easeCool', function () {stopped = true;});
				}
				
				clearInterval(sliderInterval);
				sliderInterval = setInterval(sliderFunction, timeClip);
			});
			
			$('div.bannerHPPriv .right_arrow').click(function(){
				trainLeft 	= $('div.bannerHPPriv div.train:eq(0)').css('left');
				contWidth 	= $('div.bannerHPPriv .cont:eq(0)').width();
				extraW 		= $('div.bannerHPPriv div.train:eq(0)').width() - contWidth;
				trainLeft 	= (trainLeft == 'auto') ? '0px' : trainLeft;
				widthItem	= $('div.bannerHPPriv .banner').outerWidth();
				
				stopped = false;
				if(extraW + Number(trainLeft.split('px')[0]) >= widthItem){
					$('div.bannerHPPriv div.train:eq(0)').animate({ 'left': '-=' + contWidth}, 500, 'easeCool', function () {stopped = true;});
				}
				else{
					$('div.bannerHPPriv div.train:eq(0)').animate({ 'left': '0px'}, 500, 'easeCool', function () {stopped = true;});
				}
				
				clearInterval(sliderInterval);
				sliderInterval = setInterval(sliderFunction, timeClip);
			});
		}
	},
	
	switchTab : function(el){
		$(el).parents('ul').find('li').each(function(i,e){
			$(e).removeClass('active');
		});
		$(el).parent('li').addClass('active');

		nTab = $(el).parent('li').index();
		$(el).parents('.tabs').nextAll('.boxCentral:eq(0)').find('.tabCont').each(function(i,e){
			if(i==nTab){
				$(e).addClass('active');
			}else{
				$(e).removeClass('active');
			}

		});
	},
	
	// Aggiunto un container per wrappare tab e tabCont per ovviare al css applicato a .boxCentral
	switchTab2 : function(el){
		$(el).parents('ul').find('li').each(function(i,e){
			$(e).removeClass('active');
		});
		
		$(el).parent('li').addClass('active');

		nTab = $(el).parent('li').index();
		$(el).parents('.tabsContainer').find('.tabCont').each(function(i,e){
			if(i==nTab){
				$(e).addClass('active');
			}else{
				$(e).removeClass('active');
			}

		});
	},
	
	popup : function(id){

	    if(id){	    	
	    	if(id=='noresp'){
	    		/*
    			 * Inserire qui una eventuale chiamata per salvataggio della scelta (non voglio rispondere)
    			 * 
    			 * */
	    		$('#dialog-overlay, #dialog-box').hide();       
	            return false;
	    		
	    	}else{
	    		if(id=='reminder'){
	    			/*
	    			 * Inserire qui una eventuale chiamata per salvataggio della scelta (ricordamelo pi? tardi)
	    			 * 
	    			 * */
	    			$('#dialog-overlay, #dialog-box').hide();       
	    	        return false;
	    		}else{
	    		    var message = $('#'+id).html();
	    		    $('#dialog-message').html(message);
	    		    if($('#dialog-message').find('select.popselect').size()!=0 || $('#dialog-message').find('select.popSelectSmall').size()!=0){
	    		    	if($('#dialog-message').find('.select-skinned').size()==0){
	    		    		if($('select.popselect').size()!=0){
	    		    			$('select.popselect').skinner({'type':'left','width':'315px','maxitem':'4'});
	    		    		}
	    		    		if($('select.popSelectSmall').size()!=0){
	    		    			$('select.popSelectSmall').skinner({'type':'left','width':'100%','maxitem':'4'});
	    		    		}
	    		    	}else{
	    		    		$('.select-skinned > ul').remove();
	    		    		$('.select-skinned > .select-skinned-text').remove();
	    		    		$('.select-skinned > select').unwrap();
	    		    		if($('select.popselect').size()!=0){
	    		    			$('select.popselect').skinner({'type':'left','width':'315px','maxitem':'4'});
	    		    		}
	    		    		if($('select.popSelectSmall').size()!=0){
	    		    			$('select.popSelectSmall').skinner({'type':'left','width':'100%','maxitem':'4'});
	    		    		}
	    		    	}
	    		    }
	    		    var maskHeight = $(document).height();  
	    		    var maskWidth = $(window).width();
	    		    var maskHeight2 = $(window).height();
	    		    var sT = $(document).scrollTop();
	    		     
	    		    // calculate the values for center alignment
	    		    var dialogTop =  (maskHeight2/2) - ($('#dialog-box').height()/2) + sT;  
	    		    var dialogLeft = (maskWidth/2) - ($('#dialog-box').width()/2); 
	    		     
	    		    // assign values to the overlay and dialog box
	    		    $('#dialog-overlay').css({height:maskHeight, width:maskWidth}).show();
	    		    $('#dialog-box').css({top:dialogTop, left:dialogLeft}).show();
	    		    Placeholder.init();
	    		}
	    	}    
	    }else{
		    var maskHeight = $(document).height();  
		    var maskWidth = $(window).width();
		    var maskHeight2 = $(window).height();
		    var sT = $(document).scrollTop();
		     
		    // calculate the values for center alignment
		    var dialogTop =  (maskHeight2/2) - ($('#dialog-box').height()/2) + sT;  
		    var dialogLeft = (maskWidth/2) - ($('#dialog-box').width()/2); 
		     
		    // assign values to the overlay and dialog box
		    $('#dialog-overlay').css({height:maskHeight, width:maskWidth}).show();
		    $('#dialog-box').css({top:dialogTop, left:dialogLeft}).show();
	    }
	    $('a.button, #dialog-overlay, a.btn-annulla').click(function () {     
	        $('#dialog-overlay, #dialog-box').hide();       
	        return false;
	    });  
	}
}


$(function(){ 
	l8.init();	
})

$(window).resize(function () {
	/* riposiziono popup in caso di resize */
    if (!$('#dialog-box').is(':hidden')){
    	l8.popup();       
    } 
    
    $('#data-dal, #data-al, .datepicker, .datepicker3').datepicker('hide');
  	
    /* posiziono il menu-focus in caso di resize */
	/*if($('#menu-focus').size()!=0){
		myLeftStart = Math.round($('nav > ul > li.active').position().left+(($('nav > ul > li.active').width()/2)-($('#menu-focus').width()/2)));			
		$('#menu-focus').css({'left':myLeftStart+'px'}); 
	}*/
}); 

/* modifica easing per un movimento pi? fluido */
jQuery.easing['jswing'] = jQuery.easing['swing'];
jQuery.extend(jQuery.easing, {
    easeCool: function (x, t, b, c, d) {
        return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
    }
});